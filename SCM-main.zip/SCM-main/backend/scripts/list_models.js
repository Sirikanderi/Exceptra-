import { config } from 'dotenv';
import { fileURLToPath } from 'url';
import path from 'path';

// Load env vars
const __dirname = path.dirname(fileURLToPath(import.meta.url));
config({ path: path.join(__dirname, '../.env') });

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
    console.error("❌ No GEMINI_API_KEY found in .env");
    process.exit(1);
}

const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`;

console.log(`📡 Fetching models from: ${url.replace(apiKey, 'HIDDEN_KEY')}`);

async function listModels() {
    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.error) {
            console.error("❌ API Error:", JSON.stringify(data.error, null, 2));
        } else if (data.models) {
            console.log("✅ Available Models:");
            data.models.forEach(m => {
                if (m.supportedGenerationMethods && m.supportedGenerationMethods.includes('generateContent')) {
                    console.log(`   - ${m.name.replace('models/', '')} (Supported)`);
                } else {
                    console.log(`   - ${m.name} (Not for content generation)`);
                }
            });
        } else {
            console.log("⚠️ No models found or unexpected format:", data);
        }
    } catch (err) {
        console.error("❌ Network execution error:", err);
    }
}

listModels();

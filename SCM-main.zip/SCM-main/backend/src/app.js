import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import routes from './routes.js';

// Initialize Express
const app = express();

// --- Global Middleware ---

// 1. Security Headers (Helmet)
// Essential for SaaS to prevent basic attacks like XSS
app.use(helmet());

// 2. CORS (Cross-Origin Resource Sharing)
// Controls who can access your API (Frontend, Mobile)
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*', // Lock this down in prod!
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  credentials: true
}));

// 3. Request Parsing
// Allows us to read JSON bodies and URL parameters
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 4. Logging (Morgan)
// Logs every request to the console (vital for debugging)
app.use(morgan('dev'));

//development
app.use('/api/v1', routes);

// --- Routes Placeholder ---
// We will mount routes here in later steps
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'UP', service: 'SCM Backend' });
});

// --- Global Error Handler Placeholder ---
app.use((err, req, res, next) => {
  console.error('🔥 Global Error:', err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

export default app;
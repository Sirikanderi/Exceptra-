import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema({
  organizationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Organization', 
    required: true 
  },
  actorId: { type: String, required: true }, // User who did it
  action: { type: String, required: true }, // e.g., "STOCK_UPDATE", "BILL_UPLOAD"
  resource: { type: String, required: true }, // e.g., "Inventory", "Invoice"
  resourceId: { type: String }, // The specific item ID
  
  // What changed?
  details: { type: mongoose.Schema.Types.Mixed }, 
  ipAddress: { type: String },

  timestamp: { type: Date, default: Date.now, immutable: true } // Cannot be changed
});

// Auto-expire logs after 1 year to save space (Optional Enterprise feature)
auditLogSchema.index({ timestamp: 1 }, { expireAfterSeconds: 31536000 });

export const AuditLog = mongoose.model('AuditLog', auditLogSchema);
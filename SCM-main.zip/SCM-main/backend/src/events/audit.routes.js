import { Router } from 'express';
import { requireAuth } from '../auth/auth.middleware.js';
import { AuditController } from './audit.controller.js';

const router = Router();

// GET /api/v1/audit?resource=Inventory
router.get('/', requireAuth, AuditController.getLogs);

export default router;
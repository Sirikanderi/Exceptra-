import { AuditLog } from './audit.schema.js';

export const AuditController = {
  /**
   * Get logs for the organization.
   * Supports filtering (e.g., ?resource=Inventory)
   */
  async getLogs(req, res) {
    try {
      const organizationId = req.user.organizationId;
      const { resource, action, limit = 50 } = req.query;

      // Build Filter Query
      const query = { organizationId };
      if (resource) query.resource = resource;
      if (action) query.action = action;

      // Fetch logs, newest first
      const logs = await AuditLog.find(query)
        .sort({ timestamp: -1 })
        .limit(parseInt(limit))
        .lean(); // .lean() makes it faster (returns plain JSON, not Mongoose docs)

      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to retrieve audit logs' });
    }
  }
};
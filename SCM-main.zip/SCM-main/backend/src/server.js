import { bootstrap } from './bootstrap.js';
import app from './app.js';
import analyticsRoutes from './modules/analytics/analytics.routes.js';
import forecastingRoutes from './modules/forecasting/forecasting.routes.js';

const startServer = async () => {
    try {
        await bootstrap();

        // 2. Start Listening
        const PORT = process.env.PORT || 5000;

        // Routes
        app.use('/api/v1/analytics', analyticsRoutes);
        app.use('/api/v1/forecasting', forecastingRoutes);

        app.get('/health', (req, res) => {
            res.json({ status: 'UP', service: 'SCM Backend' });
        });

        app.listen(PORT, () => {
            console.log(`
      🚀 Server running in ${process.env.NODE_ENV || 'development'} mode
      📡 Listening on http://localhost:${PORT}
`);
        });

    } catch (error) {
        console.error('❌ Fatal Error during startup:', error);
        process.exit(1);
    }
};

startServer();
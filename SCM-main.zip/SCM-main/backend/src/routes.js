import { Router } from 'express';
import { requireAuth } from './auth/auth.middleware.js';
import billingRoutes from './modules/billing/billing.routes.js';
import authRoutes from './auth/auth.routes.js';
import forecastingRoutes from './modules/forecasting/forecasting.routes.js';
import aiRoutes from './modules/ai/ai.routes.js';
import inventoryRoutes from './modules/inventory/inventory.routes.js';
import logisticsRoutes from './modules/logistics/logistics.routes.js';
import auditRoutes from './events/audit.routes.js';

const router = Router();

// Public Route (No Auth needed)
router.get('/public', (req, res) => {
  res.json({ message: 'Everyone can see this!' });
});

// Protected Route (Requires Valid Supabase Token)
router.get('/secure-data', requireAuth, (req, res) => {
  res.json({ 
    message: 'You are authenticated!', 
    userId: req.user.id,
    email: req.user.email 
  });
});

router.use('/forecasting', forecastingRoutes);
router.use('/auth', authRoutes);
router.use('/billing', billingRoutes);
router.use('/ai', aiRoutes);
router.use('/inventory', inventoryRoutes);
router.use('/logistics', logisticsRoutes);
router.use('/audit', auditRoutes);

export default router;
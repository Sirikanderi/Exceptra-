import dotenv from 'dotenv';
import { z } from 'zod';

// Load .env file
dotenv.config();

// Define the schema for our environment variables
const envSchema = z.object({
  GEMINI_API_KEY: z.string().min(1),
  AI_SERVICE_URL: z.string().url().default('http://127.0.0.1:5001'),
  PORT: z.string().default('3000'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  MONGO_URI: z.string().url(),

  // Supabase Keys
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_KEY: z.string().min(1), // Service Role Key (Admin rights)

  // CORS Security
  CORS_ORIGIN: z.string().default('*'),
});

// Validate and export
const envVars = envSchema.safeParse(process.env);

if (!envVars.success) {
  console.error('❌ Invalid Environment Variables:', envVars.error.format());
  process.exit(1);
}

export const config = envVars.data;
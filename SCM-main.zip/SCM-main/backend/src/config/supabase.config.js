import { createClient } from '@supabase/supabase-js';
import { config } from './env.config.js';

// Initialize Supabase Admin Client
// global: { headers: ... } ensures we don't accidentally leak this client to frontend
export const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});
import mongoose from 'mongoose';
import dotenv from 'dotenv';

// Load environment variables immediately
dotenv.config();

export const bootstrap = async () => {
  console.log('🔄 Bootstrapping SCM Backend...');

  // 1. Validate Environment Variables
  // (We will expand this in Step 2 with strict validation)
  if (!process.env.PORT) {
    console.warn('⚠️ PORT not defined in .env, defaulting to 3000');
  }

  // 2. Database Connection
  // We handle the connection here so the server logic stays clean
  try {
    const dbUri = process.env.MONGO_URI; 
    if (!dbUri) {
      throw new Error('❌ MONGO_URI is missing in .env');
    }
    
    await mongoose.connect(dbUri);
    console.log('✅ MongoDB Connected successfully');
    
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    process.exit(1); // Critical failure: Stop the app
  }

  // Return any dependencies if needed (optional for now)
  return { status: 'ready' };
};
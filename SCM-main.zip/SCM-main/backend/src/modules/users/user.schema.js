import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    // This ID comes from Supabase (Auth)
    supabaseId: {
        type: String,
        required: true,
        unique: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    name: { type: String },
    role: {
        type: String,
        enum: ['admin', 'manager', 'driver', 'shopkeeper', 'supplier'],
        default: 'shopkeeper'
    },
    // The vital link to Multi-tenancy
    organizationId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Organization',
        required: true
    },
    createdAt: { type: Date, default: Date.now }
});

// Index for fast lookups during Auth
// userSchema.index({ supabaseId: 1 }); // Removed to avoid duplicate index warning (already unique: true)
userSchema.index({ organizationId: 1 });

export const User = mongoose.model('User', userSchema);
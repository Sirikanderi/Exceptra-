import mongoose from 'mongoose';

const invoiceSchema = new mongoose.Schema({
  organizationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Organization', 
    required: true 
  },
  // From CSV
  invoiceNumber: { type: String, required: true },
  customerName: { type: String },
  date: { type: Date, required: true },
  totalAmount: { type: Number, required: true },
  
  // The items sold in this invoice
  items: [{
    sku: String,
    name: String,
    quantity: Number,
    price: Number
  }],
  
  // Payment Status (for later)
  status: { 
    type: String, 
    enum: ['paid', 'pending', 'overdue'], 
    default: 'paid' 
  },
  
  createdAt: { type: Date, default: Date.now }
});

// Index date for fast "Sales over time" queries (AI loves this)
invoiceSchema.index({ organizationId: 1, date: -1 });

export const Invoice = mongoose.model('Invoice', invoiceSchema);
import { BillingService } from './billing.service.js';

export const BillingController = {
  async uploadCsv(req, res) {
    try {
      // 1. Basic Validation
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      // 2. Call Service
      // req.user.organizationId comes from our Auth Middleware
      const result = await BillingService.processInvoiceCsv(
        req.file.buffer, 
        req.user.organizationId
      );

      // 3. Send Response
      res.status(201).json({
        message: 'Processing complete',
        data: result
      });

    } catch (error) {
      console.error('CSV Upload Error:', error);
      res.status(500).json({ 
        error: 'Processing failed', 
        details: error.message 
      });
    }
  }
};
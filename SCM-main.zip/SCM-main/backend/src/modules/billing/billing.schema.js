import mongoose from 'mongoose';

const inventorySchema = new mongoose.Schema({
  organizationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Organization', 
    required: true 
  },
  sku: { 
    type: String, 
    required: true 
  }, // Stock Keeping Unit (Unique ID)
  name: { type: String, required: true },
  category: { type: String },
  
  // Current Status
  quantity: { type: Number, default: 0 },
  unitPrice: { type: Number, required: true },
  location: { type: String }, // Warehouse A, Shelf B
  
  // AI & Forecasting Hooks
  reorderPoint: { type: Number, default: 10 },
  safetyStock: { type: Number, default: 5 },
  
  // Last time this record was touched
  lastUpdated: { type: Date, default: Date.now }
});

// Compound index: A SKU must be unique *within* an Organization, 
// but two different shops can both have an item named "Apple".
inventorySchema.index({ organizationId: 1, sku: 1 }, { unique: true });

export const Inventory = mongoose.model('Inventory', inventorySchema);
import { Readable } from 'stream';
import csv from 'csv-parser';
import mongoose from 'mongoose';
import { Invoice } from './invoice.schema.js';
import { InventoryService } from '../inventory/inventory.service.js';

export const BillingService = {
  async processInvoiceCsv(buffer, organizationId) {
    const validRows = [];
    const errors = [];

    const stream = Readable.from(buffer.toString());

    return new Promise((resolve, reject) => {
      stream
        .pipe(csv())
        .on('data', (row) => {
          try {
            const cleanRow = normalizeRow(row);
            validRows.push(cleanRow);
          } catch (err) {
            errors.push({
              row,
              error: err.message
            });
          }
        })
        .on('end', async () => {
          if (validRows.length === 0) {
            return resolve({
              success: false,
              message: 'No valid rows found',
              errors
            });
          }

          const session = await mongoose.startSession();
          session.startTransaction();

          try {
            const invoiceDocs = validRows.map((row) => ({
              organizationId,
              invoiceNumber: row.invoice_no,
              customerName: row.customer_name,
              date: new Date(row.date),
              totalAmount: row.amount,
              // Hardcoded items array for testing (Replacing parseItems logic)
              items: [{ sku: 'APPLE', quantity: 5, price: 20 }], 
              status: 'paid'
            }));

            // 1️⃣ Insert invoices
            await Invoice.insertMany(invoiceDocs, { session });

            // 2️⃣ Update inventory for each invoice item
            for (const invoice of invoiceDocs) {
              for (const item of invoice.items) {
                await InventoryService.processSale(
                  {
                    sku: item.sku,
                    quantity: item.quantity
                  },
                  organizationId,
                  session
                );
              }
            }

            await session.commitTransaction();
            session.endSession();

            resolve({
              success: true,
              inserted: invoiceDocs.length,
              errors
            });
          } catch (err) {
            await session.abortTransaction();
            session.endSession();
            reject(err);
          }
        })
        .on('error', reject);
    });
  }
};

function normalizeRow(row) {
  if (!row.invoice_no || !row.amount || !row.items) {
    throw new Error('Missing required fields');
  }

  const amount = parseFloat(
    typeof row.amount === 'string'
      ? row.amount.replace(/,/g, '')
      : row.amount
  );

  if (isNaN(amount)) {
    throw new Error('Invalid amount');
  }

  return {
    ...row,
    amount
  };
}

/**
 * CSV format example:
 * items = "SKU001:2;SKU002:1"
 */
function parseItems(itemsString) {
  return itemsString.split(';').map((item) => {
    const [sku, quantity] = item.split(':');

    if (!sku || !quantity) {
      throw new Error('Invalid items format');
    }

    return {
      sku: sku.trim(),
      quantity: parseInt(quantity, 10)
    };
  });
}























/* import { Readable } from 'stream';
import csv from 'csv-parser';
import mongoose from 'mongoose';
import { Invoice } from './invoice.schema.js';
import { Inventory } from '../inventory/inventory.schema.js';
import { InventoryService } from '../inventory/inventory.service.js'; */

/* export const BillingService = {
  /**
   * Processes a CSV buffer and bulk inserts invoices.
   * Atomic Transaction: If one critical thing fails, we rollback (optional but recommended).
   */
  /* async processInvoiceCsv(buffer, organizationId) {
    const results = [];
    const errors = []; */ 
    
 /*    // 1. Convert Buffer to Stream
    const stream = Readable.from(buffer.toString());

    return new Promise((resolve, reject) => {
      stream
        .pipe(csv())
        .on('data', (row) => {
          try {
            // 2. Normalize & Validate Data (The "Dirty Work")
            const cleanData = normalizeRow(row);
            if (cleanData) {
              results.push(cleanData);
            }
          } catch (err) {
            errors.push({ row, error: err.message });
          }
        })
        .on('end', async () => {
          if (results.length === 0) {
            return resolve({ success: false, message: 'No valid rows found', errors });
          }

          // 3. Database Transaction (Safety First)
          const session = await mongoose.startSession();
          session.startTransaction();

          try {
            // Transform raw data into Invoice Documents
            const invoiceDocs = results.map(data => ({
              organizationId,
              invoiceNumber: data.invoice_no,
              customerName: data.customer,
              date: new Date(data.date), // Ensure your CSV date format matches!
              totalAmount: parseFloat(data.amount),
              items: parseItems(data.items), // Assume items are JSON or a simple string for now
              status: 'paid'
            }));

            // Bulk Insert
            await Invoice.insertMany(invoiceDocs, { session });
            
            // TODO: Update Inventory counts here (Step 6)

            await session.commitTransaction();
            session.endSession();

            resolve({ 
              success: true, 
              count: results.length, 
              errors 
            });

          } catch (dbError) {
            await session.abortTransaction();
            session.endSession();
            reject(dbError);
          }
        })
        .on('error', (error) => reject(error));
    });
  }
}; */

// --- Helper Functions (Keep logic clean) ---
/* 
function normalizeRow(row) {
  // Validate required fields
  if (!row.invoice_no || !row.amount) {
    throw new Error('Missing invoice_no or amount');
  }

  // Handle "1,000.00" strings
  const amount = typeof row.amount === 'string' 
    ? parseFloat(row.amount.replace(/,/g, '')) 
    : row.amount;

  if (isNaN(amount)) throw new Error('Invalid Amount');

  return { ...row, amount };
}

function parseItems(itemsString) {
  // If your CSV has a column "items" like "Apple:2;Milk:1"
  // You would parse it here. For now, returning empty to keep it simple.
  return []; 
} */
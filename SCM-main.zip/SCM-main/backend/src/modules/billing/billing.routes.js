import { Router } from 'express';
import multer from 'multer';
import { requireAuth } from '../../auth/auth.middleware.js';
import { BillingController } from './billing.controller.js';

const router = Router();

// Configure Multer (Memory Storage)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // Limit to 5MB
});

// POST /api/v1/billing/upload
router.post(
  '/upload', 
  requireAuth,              // 1. Check Login
  upload.single('file'),    // 2. Parse File
  BillingController.uploadCsv // 3. Process Logic
);

export default router;
import { Supplier } from './supplier.schema.js';

export const SupplierController = {
    // Get all suppliers
    getAll: async (req, res) => {
        try {
            const suppliers = await Supplier.find().sort({ createdAt: -1 });
            res.json(suppliers);
        } catch (error) {
            res.status(500).json({ message: 'Failed to fetch suppliers', error: error.message });
        }
    },

    // Add new supplier
    create: async (req, res) => {
        try {
            const { name, contact, email, category, address } = req.body;

            const existing = await Supplier.findOne({ email });
            if (existing) {
                return res.status(400).json({ message: 'Supplier with this email already exists' });
            }

            const supplier = new Supplier({
                name,
                contact,
                email,
                category,
                address
            });

            await supplier.save();
            res.status(201).json(supplier);
        } catch (error) {
            res.status(500).json({ message: 'Failed to create supplier', error: error.message });
        }
    },

    // Delete supplier
    delete: async (req, res) => {
        try {
            await Supplier.findByIdAndDelete(req.params.id);
            res.json({ message: 'Supplier deleted successfully' });
        } catch (error) {
            res.status(500).json({ message: 'Failed to delete supplier', error: error.message });
        }
    }
};

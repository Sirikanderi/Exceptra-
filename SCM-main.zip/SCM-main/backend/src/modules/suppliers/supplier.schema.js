import mongoose from 'mongoose';

const SupplierSchema = new mongoose.Schema({
    name: { type: String, required: true },
    contact: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    category: { type: String, required: true },
    address: { type: String },
    rating: { type: Number, default: 0 },
    status: { type: String, enum: ['Active', 'Inactive', 'Review Needed'], default: 'Active' },
    createdAt: { type: Date, default: Date.now }
});

export const Supplier = mongoose.model('Supplier', SupplierSchema);

import { Router } from 'express';
import { requireAuth } from '../../auth/auth.middleware.js';
import { SupplierController } from './supplier.controller.js';

const router = Router();

router.get('/', requireAuth, SupplierController.getAll);
router.post('/add', requireAuth, SupplierController.create);
router.delete('/:id', requireAuth, SupplierController.delete);

export default router;

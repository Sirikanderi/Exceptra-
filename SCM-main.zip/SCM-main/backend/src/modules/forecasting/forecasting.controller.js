import { SalesHistory } from './sales_history.schema.js';
import { MarketData } from './market_data.schema.js';
import { config } from '../../config/env.config.js';
import * as XLSX from 'xlsx';
import axios from 'axios';

export const ForecastingController = {
    // Bulk Import Historical Data
    async uploadHistory(req, res) {
        try {
            if (!req.file) {
                return res.status(400).json({ error: 'No file uploaded' });
            }

            const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const data = XLSX.utils.sheet_to_json(sheet);

            if (!data || data.length === 0) {
                return res.status(400).json({ error: 'Empty file or invalid format' });
            }

            const organizationId = req.user.organizationId;
            const operations = [];

            // Expected columns: SKU, Date, Quantity, Unit Price, Product Name, Category
            for (const row of data) {
                // Normalize keys (handle case sensitivity)
                const sku = row['SKU'] || row['sku'];
                const dateStr = row['Date'] || row['date'];
                const quantity = Number(row['Quantity'] || row['quantity'] || row['Qty']);
                const price = Number(row['Unit Price'] || row['unit price'] || row['Price']);
                const name = row['Product Name'] || row['product name'] || row['Name'];
                const category = row['Category'] || row['category'];

                if (sku && dateStr && !isNaN(quantity)) {
                    let date;
                    if (typeof dateStr === 'number') {
                        date = new Date((dateStr - (25567 + 2)) * 86400 * 1000); // Excel date to JS
                    } else {
                        date = new Date(dateStr);
                    }

                    if (!isNaN(date.getTime())) {
                        operations.push({
                            updateOne: {
                                filter: { organizationId, sku, date },
                                update: {
                                    $set: {
                                        productName: name,
                                        category: category,
                                        quantitySold: quantity,
                                        unitPrice: price || 0,
                                        totalAmount: quantity * (price || 0),
                                        sourceFile: req.file.originalname,
                                        uploadedAt: new Date()
                                    }
                                },
                                upsert: true
                            }
                        });
                    }
                }
            }

            if (operations.length > 0) {
                await SalesHistory.bulkWrite(operations);
            }

            res.json({
                message: `Successfully processed ${operations.length} records.`,
                count: operations.length
            });

        } catch (error) {
            console.error('Import Error:', error);
            res.status(500).json({ error: error.message });
        }
    },

    async uploadMarketData(req, res) {
        try {
            if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

            const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const data = XLSX.utils.sheet_to_json(sheet);

            if (!data.length) return res.status(400).json({ error: 'Empty file' });

            const operations = [];
            for (const row of data) {
                // Expecting: Date, Value, Region (opt), Indicator (opt)
                const dateStr = row['Date'] || row['date'];
                const value = row['Value'] || row['value'] || row['Index'];
                const region = row['Region'] || row['region'] || 'Nagpur';
                const indicator = row['Indicator'] || row['Type'] || 'General Demand';

                if (dateStr && value !== undefined) {
                    let date;
                    if (typeof dateStr === 'number') {
                        date = new Date((dateStr - (25567 + 2)) * 86400 * 1000);
                    } else {
                        date = new Date(dateStr);
                    }

                    if (!isNaN(date.getTime())) {
                        operations.push({
                            updateOne: {
                                filter: { region, date, indicatorName: indicator },
                                update: { $set: { value: Number(value) } },
                                upsert: true
                            }
                        });
                    }
                }
            }

            if (operations.length > 0) {
                await MarketData.bulkWrite(operations);
            }
            res.json({ message: `Processed ${operations.length} market data points.` });

        } catch (error) {
            console.error(error);
            res.status(500).json({ error: error.message });
        }
    },

    async getSkus(req, res) {
        try {
            const organizationId = req.user.organizationId;
            const skus = await SalesHistory.distinct('sku', { organizationId });
            res.json(skus);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    },

    // Actual Forecast Logic calling Python Service
    async getForecast(req, res) {
        try {
            const { sku } = req.params;

            // Call Python Service
            const response = await axios.post(`${config.AI_SERVICE_URL}/train-predict`, {
                sku: sku,
                periods: 730 // Forecast next 2 years
            });

            const forecastData = response.data;

            // Optional: call Gemini here to explain the data
            // const explanation = await AIService.explainForecast(forecastData);
            // forecastData.explanation = explanation;

            // Return the array of data points as expected by frontend
            if (forecastData.forecast) {
                res.json(forecastData);
            } else {
                res.status(500).json({ error: "Invalid response from Forecasting Engine" });
            }

        } catch (error) {
            console.error('Forecasting Error:', error.message);
            // Fallback for demo/error handling if Python service is down
            if (error.code === 'ECONNREFUSED') {
                return res.status(503).json({
                    error: "Forecasting Engine Unavailable",
                    message: "The AI service is currently offline. Please try again later."
                });
            }
            res.status(500).json({ error: error.message });
        }
    }
};
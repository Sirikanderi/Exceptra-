import mongoose from 'mongoose';

const salesHistorySchema = new mongoose.Schema({
    organizationId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Organization',
        required: true
    },
    sku: {
        type: String,
        required: true,
        index: true
    },
    productName: { type: String }, // redundant but useful for display without joins
    category: { type: String },

    // Time-Series Data Point
    date: {
        type: Date,
        required: true,
        index: true
    },
    quantitySold: { type: Number, required: true },
    unitPrice: { type: Number, required: true },
    totalAmount: { type: Number }, // calculated

    // Metadata
    uploadedAt: { type: Date, default: Date.now },
    sourceFile: { type: String } // e.g., "sales_2021_2025.csv"
});

// Compound index for unique daily records per product (optional, depends on granularity)
// If data is daily, this prevents duplicates.
salesHistorySchema.index({ organizationId: 1, sku: 1, date: 1 }, { unique: true });

export const SalesHistory = mongoose.model('SalesHistory', salesHistorySchema);

import axios from 'axios';
import { config } from '../../config/env.config.js';
import { Invoice } from '../billing/invoice.schema.js';

export const ForecastingService = {
  /**
   * Prepares data and asks Python for a forecast.
   */
  async generateForecast(organizationId, sku) {
    // 1. Fetch Historical Data from MongoDB
    // We need "Date" and "Quantity Sold" for this SKU
    const salesHistory = await Invoice.aggregate([
      { $match: { organizationId: new mongoose.Types.ObjectId(organizationId) } },
      { $unwind: '$items' },
      { $match: { 'items.sku': sku } },
      { $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } }, // Group by Day
          totalQty: { $sum: "$items.quantity" }
      }},
      { $sort: { _id: 1 } } // Sort by date ascending (Critical for ARIMA)
    ]);

    // Format for Python: [{ date: '2023-10-01', value: 50 }, ...]
    const timeSeriesData = salesHistory.map(record => ({
      date: record._id,
      value: record.totalQty
    }));

    if (timeSeriesData.length < 5) {
      throw new Error('Not enough historical data for forecasting (min 5 days needed)');
    }

    // 2. Call Python Microservice
    try {
      const response = await axios.post(`${config.AI_SERVICE_URL}/predict`, {
        algorithm: 'ARIMA',
        data: timeSeriesData,
        periods: 7 // Predict next 7 days
      });

      return response.data; // { forecast: [ ... ], confidence: 0.95 }

    } catch (error) {
      console.error('❌ AI Service Failed:', error.message);
      // Fallback: Return a naive average if AI fails
      return this.calculateNaiveForecast(timeSeriesData);
    }
  },

  calculateNaiveForecast(data) {
    const sum = data.reduce((acc, curr) => acc + curr.value, 0);
    const avg = sum / data.length;
    return { 
      forecast: Array(7).fill(Math.round(avg)), 
      note: 'Fallback: Simple Average (AI Offline)' 
    };
  }
};
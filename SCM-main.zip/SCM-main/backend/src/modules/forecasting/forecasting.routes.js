import { Router } from 'express';
import multer from 'multer';
import { requireAuth } from '../../auth/auth.middleware.js';
import { ForecastingController } from './forecasting.controller.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

router.post('/upload-history', requireAuth, upload.single('file'), ForecastingController.uploadHistory);
router.post('/upload-market-data', requireAuth, upload.single('file'), ForecastingController.uploadMarketData);
router.get('/skus', requireAuth, ForecastingController.getSkus);
router.get('/predict/:sku', requireAuth, ForecastingController.getForecast);

export default router;
import mongoose from 'mongoose';

const marketDataSchema = new mongoose.Schema({
    region: {
        type: String,
        required: true,
        default: 'Nagpur' // defaulting as per user request
    },
    date: {
        type: Date,
        required: true,
        index: true
    },
    // The "Market Factor" or "Index" (e.g., "General Ag Market Demand", "Festival Season Index")
    indicatorName: {
        type: String,
        required: true
    },
    // Normalized value (e.g., 0-100 or 0.0-1.0) indicating demand intensity
    value: {
        type: Number,
        required: true
    },
    uploadedAt: { type: Date, default: Date.now }
});

// Avoid duplicates for same region/date/indicator
marketDataSchema.index({ region: 1, date: 1, indicatorName: 1 }, { unique: true });

export const MarketData = mongoose.model('MarketData', marketDataSchema);

import mongoose from 'mongoose';

const shipmentSchema = new mongoose.Schema({
  organizationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Organization', 
    required: true 
  },
  // Tracking ID (e.g., "TRK-9988")
  trackingId: { type: String, required: true, unique: true },
  
  driverId: { type: String }, // Supabase ID of the driver
  vehicleNumber: { type: String },
  
  // What is being moved?
  items: [{
    sku: String,
    quantity: Number
  }],

  // Route Details
  origin: { type: String, required: true },
  destination: { type: String, required: true },
  
  // State
  status: { 
    type: String, 
    enum: ['PENDING', 'IN_TRANSIT', 'DELIVERED', 'DELAYED', 'CANCELLED'], 
    default: 'PENDING'
  },
  
  estimatedArrival: { type: Date },
  
  // The "Log" of what happened during the trip
  events: [{
    status: String,       // e.g., "Vehicle Breakdown"
    location: String,     // e.g., "Highway 44"
    timestamp: { type: Date, default: Date.now },
    note: String
  }],

  createdAt: { type: Date, default: Date.now }
});

export const Shipment = mongoose.model('Shipment', shipmentSchema);
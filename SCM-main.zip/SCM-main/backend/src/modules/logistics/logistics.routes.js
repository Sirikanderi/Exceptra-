import { Router } from 'express';
import { requireAuth } from '../../auth/auth.middleware.js';
import { LogisticsController } from './logistics.controller.js';

const router = Router();


router.get('/', requireAuth, LogisticsController.getAll);
router.post('/create', requireAuth, LogisticsController.create);
router.post('/:trackingId/update', requireAuth, LogisticsController.updateEvent);
router.post('/route-change', requireAuth, LogisticsController.routeUpdate);

export default router;
import { Shipment } from './shipment.schema.js';
import { AuditLog } from '../../events/audit.schema.js';

export const LogisticsService = {
  /**
   * Create a new shipment
   */
  async createShipment(data) {
    const shipment = await Shipment.create({
      ...data,
      trackingId: `TRK-${Date.now().toString().slice(-6)}` // Simple auto-ID
    });
    return shipment;
  },

  /**
   * Update shipment status (e.g., Driver reports "Stuck in Traffic")
   */
  async updateStatus(trackingId, status, location, note, userId, organizationId) {
    // 1. Find and Update Shipment
    const shipment = await Shipment.findOne({ trackingId, organizationId });
    if (!shipment) throw new Error('Shipment not found');

    shipment.status = status;
    shipment.events.push({
      status,
      location,
      note,
      timestamp: new Date()
    });

    await shipment.save();

    // 2. Write to Global Audit Log (Trust Layer)
    // Even if the driver deletes the app, this log remains in the database.
    await AuditLog.create({
      organizationId,
      actorId: userId,
      action: 'SHIPMENT_UPDATE',
      resource: 'Shipment',
      resourceId: shipment._id,
      details: { status, location, note }
    });

    return shipment;
  }
};
import { Inventory } from './inventory.schema.js'; // <--- UPDATED
import { AuditLog } from '../../events/audit.schema.js'; // <--- UPDATED

export const InventoryService = {
  /**
   * Process a sale: Reduce stock and check health.
   * @param {Object} item - { sku, quantity }
   * @param {String} organizationId
   * @param {Object} session - Mongoose Transaction Session
   */
  async processSale(item, organizationId, session) {
    const { sku, quantity } = item;

    // 1. Find the item and atomically decrement
    const updatedItem = await Inventory.findOneAndUpdate(
      { organizationId, sku },
      { 
        $inc: { quantity: -quantity }, 
        $set: { lastUpdated: new Date() }
      },
      { new: true, session }
    );

    if (!updatedItem) {
      // In a strict system, we reject the bill if the item doesn't exist.
      throw new Error(`SKU ${sku} not found in inventory.`);
    }

    // 2. Check Logic: Is stock dangerous?
    const riskStatus = this.calculateRisk(updatedItem);

    // 3. Log the Event (Audit Trail)
    await AuditLog.create([{
      organizationId,
      actorId: 'SYSTEM_BILLING', 
      action: 'STOCK_DEDUCTION',
      resource: 'Inventory',
      resourceId: updatedItem._id,
      details: { 
        sku, 
        sold: quantity, 
        remaining: updatedItem.quantity, 
        risk: riskStatus 
      }
    }], { session });

    return { 
      sku, 
      remaining: updatedItem.quantity, 
      risk: riskStatus 
    };
  },

  calculateRisk(item) {
    if (item.quantity <= 0) return 'OUT_OF_STOCK';
    if (item.quantity <= item.reorderPoint) return 'LOW_STOCK';
    return 'HEALTHY';
  }
};
import { Router } from 'express';
import { requireAuth } from '../../auth/auth.middleware.js';
import { InventoryController } from './inventory.controller.js';
import multer from 'multer';

const upload = multer({ storage: multer.memoryStorage() });
const router = Router();

router.post('/add', requireAuth, InventoryController.addItem);
router.get('/', requireAuth, InventoryController.getInventory);
router.post('/import', requireAuth, upload.single('file'), InventoryController.importInventory);

export default router;
import { Inventory } from './inventory.schema.js';
import * as XLSX from 'xlsx';

export const InventoryController = {
    // Add a new item manually
    async addItem(req, res) {
        try {
            const { sku, name, quantity, unitPrice, reorderPoint } = req.body;
            const organizationId = req.user.organizationId;

            const newItem = await Inventory.create({
                organizationId,
                sku,
                name,
                quantity,
                unitPrice,
                reorderPoint
            });

            res.status(201).json(newItem);
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    },

    // Get all items (to see the result of your CSV upload)
    async getInventory(req, res) {
        try {
            const items = await Inventory.find({ organizationId: req.user.organizationId }).sort({ lastUpdated: -1 });
            res.json(items);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    },

    // Bulk Import from XLSX
    async importInventory(req, res) {
        try {
            if (!req.file) {
                return res.status(400).json({ message: 'No file uploaded' });
            }

            const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const data = XLSX.utils.sheet_to_json(sheet);

            const organizationId = req.user.organizationId;
            const results = { success: 0, failed: 0, errors: [] };

            for (const row of data) {
                // Flexible Mapping (supports user's python script)
                // Python columns: "PRODUCT NAME", "SKU", "CATEGORY", "CURRENT STOCK", "UNIT PRICE", "REORDER LEVEL", "STATUS"

                const sku = row['SKU'] || row['sku'];
                const name = row['PRODUCT NAME'] || row['Product Name'] || row['name'] || row['Name'];
                const category = row['CATEGORY'] || row['Category'] || row['category'] || 'Uncategorized';

                // Parse Numbers carefully
                const quantity = Number(row['CURRENT STOCK'] || row['Current Stock'] || row['Quantity'] || row['quantity'] || 0);
                const unitPrice = Number(row['UNIT PRICE'] || row['Unit Price'] || row['Price'] || row['price'] || 0);
                const reorderPoint = Number(row['REORDER LEVEL'] || row['Reorder Level'] || row['Reorder Point'] || row['reorderPoint'] || 10);

                if (!name || !sku) {
                    results.failed++;
                    continue;
                }

                try {
                    // Upsert based on SKU + Organization
                    await Inventory.findOneAndUpdate(
                        { organizationId, sku },
                        {
                            organizationId,
                            sku,
                            name,
                            quantity,
                            unitPrice,
                            category,
                            reorderPoint,
                            lastUpdated: new Date()
                        },
                        { upsert: true, new: true }
                    );
                    results.success++;
                } catch (err) {
                    results.failed++;
                    results.errors.push({ sku, error: err.message });
                }
            }

            res.json({ message: 'Import processed', results });

        } catch (error) {
            console.error('Import error:', error);
            res.status(500).json({ message: 'Failed to process import', error: error.message });
        }
    }
};

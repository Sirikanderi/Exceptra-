import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from '../../config/env.config.js';

// Initialize Gemini
const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-flash-latest' });

export const AIService = {
    /**
     * Generates a risk explanation based on structured data.
     * We do NOT ask the AI to calculate the risk; we tell it the risk
     * and ask it to explain the "Why" and "What now".
     */
    async explainRisk(sku, currentStock, riskLevel, forecastData) {
        try {
            // 1. Construct the Context (Prompt Engineering)
            const prompt = `
        Role: Senior Supply Chain Risk Analyst.
        Task: Explain the inventory risk for a specific item to a shopkeeper.
        
        Data Context:
        - Item SKU: ${sku}
        - Current Stock: ${currentStock} units
        - Calculated Risk Level: ${riskLevel} (Criticality: ${riskLevel === 'OUT_OF_STOCK' ? 'High' : 'Medium'})
        - Forecasted Demand (Next 7 days): ${JSON.stringify(forecastData)}
        
        Instructions:
        1. Start with a direct "Action Item" (e.g., "Reorder immediately").
        2. Explain *why* using the data (e.g., "You have 5 units but demand is rising").
        3. Keep it professional, concise (under 50 words), and urgent.
        4. Do NOT invent numbers. Use only the data provided.
      `;

            // 2. Call the Model
            const result = await model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();

            return {
                sku,
                explanation: text,
                generatedAt: new Date()
            };

        } catch (error) {
            console.error('🧠 GenAI Error:', error.message);
            // Fail Gracefully: Never break the app because the "Smart" feature failed
            return {
                sku,
                explanation: "Automated analysis unavailable. Please review stock levels manually.",
                error: true
            };
        }
    }
};
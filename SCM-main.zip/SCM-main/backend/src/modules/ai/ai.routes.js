import { Router } from 'express';
import { requireAuth } from '../../auth/auth.middleware.js';
import { AIController } from './ai.controller.js';

const router = Router();

// POST because we might send custom parameters later, but GET is fine too.
// Let's use GET for semantic correctness.
router.get('/analyze/:sku', requireAuth, AIController.getStockAnalysis);

export default router;
import { AIService } from './ai.service.js';
import { Inventory } from '../inventory/inventory.schema.js';

export const AIController = {
  async getStockAnalysis(req, res) {
    try {
      const { sku } = req.params;
      const organizationId = req.user.organizationId;

      // 1. Fetch Real Data (The "Ground Truth")
      const item = await Inventory.findOne({ organizationId, sku });
      
      if (!item) {
        return res.status(404).json({ error: 'Item not found' });
      }

      // 2. Mock Forecast Data (In Step 7 we built the real service, 
      // but for this specific isolation test, we can simulate it if needed.
      // Ideally, you call ForecastingService.generateForecast(organizationId, sku) here.)
      const mockForecast = [10, 12, 15, 12, 10, 8, 9]; // Example demand

      // 3. Ask AI to explain
      const analysis = await AIService.explainRisk(
        item.sku, 
        item.quantity, 
        item.quantity <= item.reorderPoint ? 'LOW_STOCK' : 'HEALTHY',
        mockForecast
      );

      res.json(analysis);

    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
};
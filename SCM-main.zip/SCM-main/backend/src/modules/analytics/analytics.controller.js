import { Inventory } from '../inventory/inventory.schema.js';
import { Shipment } from '../logistics/shipment.schema.js';

export const AnalyticsController = {
    async getDashboardStats(req, res) {
        try {
            const organizationId = req.user.organizationId;

            const [inventoryStats, pendingDeliveries, stockoutRisks] = await Promise.all([
                // 1. Total Inventory Count & Value
                Inventory.aggregate([
                    { $match: { organizationId } },
                    {
                        $group: {
                            _id: null,
                            totalQuantity: { $sum: "$quantity" },
                            totalValue: { $sum: { $multiply: ["$quantity", "$unitPrice"] } }
                        }
                    }
                ]),

                // 2. Pending Deliveries
                Shipment.countDocuments({
                    organizationId,
                    status: { $in: ['PENDING', 'IN_TRANSIT'] }
                }),

                // 3. Stockout Risks (Quantity <= ReorderPoint)
                Inventory.countDocuments({
                    organizationId,
                    $expr: { $lte: ["$quantity", "$reorderPoint"] }
                })
            ]);

            const stats = {
                totalInventory: inventoryStats[0]?.totalQuantity || 0,
                totalValue: inventoryStats[0]?.totalValue || 0,
                pendingDeliveries: pendingDeliveries || 0,
                stockoutRisk: stockoutRisks || 0
            };

            res.json(stats);
        } catch (error) {
            console.error('Analytics Error:', error);
            res.status(500).json({ error: error.message });
        }
    }
};

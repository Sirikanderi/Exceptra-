import { Router } from 'express';
import { requireAuth } from '../../auth/auth.middleware.js';
import { AnalyticsController } from './analytics.controller.js';

const router = Router();

router.get('/dashboard', requireAuth, AnalyticsController.getDashboardStats);

export default router;

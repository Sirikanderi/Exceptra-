import mongoose from 'mongoose';

const orgSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true, 
    trim: true 
  },
  // Unique code for things like bills (e.g., "SHP-001")
  slug: { 
    type: String, 
    unique: true, 
    lowercase: true,
    trim: true
  },
  // Settings specific to this business
  settings: {
    currency: { type: String, default: 'INR' },
    lowStockThreshold: { type: Number, default: 10 }
  },
  // Link to the owner (User ID)
  ownerId: { 
    type: String, // Storing Supabase UUID here
    required: true 
  },
  createdAt: { type: Date, default: Date.now }
});

export const Organization = mongoose.model('Organization', orgSchema);
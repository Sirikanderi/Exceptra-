import { supabase } from '../config/supabase.config.js';
import { User } from '../modules/users/user.schema.js';

export const requireAuth = async (req, res, next) => {
    try {
        // 1. Check for Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                error: 'Unauthorized',
                message: 'Missing or invalid authentication token'
            });
        }

        // 2. Extract Token
        const token = authHeader.split(' ')[1];

        // 3. Verify with Supabase
        const { data: { user }, error } = await supabase.auth.getUser(token);

        if (error || !user) {
            console.error('Auth Middleware - Supabase Verification Failed:', error?.message);
            return res.status(401).json({
                error: 'Unauthorized',
                message: 'Invalid or expired token'
            });
        }

        // 4. Fetch User Profile from MongoDB
        const dbUser = await User.findOne({ supabaseId: user.id });

        if (!dbUser) {
            console.error('Auth Middleware - DB User Not Found for Supabase ID:', user.id);
            return res.status(401).json({
                error: 'Unauthorized',
                message: 'User profile not found in database. Please contact support.'
            });
        }

        // 5. Attach User to Request
        req.auth = user; // Pure Supabase Auth User
        req.user = dbUser; // Our Rich MongoDB User (with organizationId, role, etc.)

        next();
    } catch (err) {
        console.error('Auth Middleware Error:', err);
        res.status(500).json({ error: 'Internal Server Authentication Error' });
    }
};
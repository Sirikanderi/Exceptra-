import { AuthService } from './auth.service.js';

export const AuthController = {
    async register(req, res) {
        try {
            const { email, password, name, organizationName, role } = req.body;

            // Basic Validation
            if (!email || !password || !name) {
                return res.status(400).json({ error: 'Missing required fields' });
            }

            // Auto-generate organization name if not provided
            const finalOrgName = organizationName || `${name}'s Store`;

            const result = await AuthService.register({
                email,
                password,
                name,
                organizationName: finalOrgName,
                role
            });

            res.status(201).json({
                message: 'Registration successful',
                data: result
            });
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    },

    async login(req, res) {
        try {
            const { email, password } = req.body;

            const { session, user } = await AuthService.login({ email, password });

            res.status(200).json({
                message: 'Login successful',
                access_token: session.access_token,
                user: user // Return the MongoDB user which has the role
            });
        } catch (error) {
            res.status(401).json({ error: 'Login failed', details: error.message });
        }
    },

    async getMe(req, res) {
        try {
            // req.user is populated by requireAuth middleware
            res.json(req.user);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
};
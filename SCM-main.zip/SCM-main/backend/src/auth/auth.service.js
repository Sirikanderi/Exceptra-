import { supabase } from '../config/supabase.config.js';
import { User } from '../modules/users/user.schema.js';
import { Organization } from '../modules/organizations/org.schema.js';

export const AuthService = {
    /**
     * Register a new Shop Owner.
     * Creates Supabase Auth User + MongoDB Organization + MongoDB User
     */
    async register({ email, password, name, organizationName, role }) {
        // 1. Create Auth User in Supabase
        const { data: authData, error: authError } = await supabase.auth.signUp({
            email,
            password,
        });

        if (authError) throw new Error(`Supabase Error: ${authError.message}`);

        // Note: If you have "Confirm Email" on in Supabase, user won't be able to login yet.
        // For dev, go to Supabase Dashboard -> Auth -> Providers -> Email -> Disable "Confirm Email"

        const supabaseId = authData.user.id;

        // 2. Create the Organization in MongoDB
        const newOrg = await Organization.create({
            name: organizationName,
            slug: organizationName.toLowerCase().replace(/ /g, '-') + '-' + Math.floor(Math.random() * 1000),
            ownerId: supabaseId
        });

        // 3. Create the User Profile in MongoDB
        const newUser = await User.create({
            supabaseId: supabaseId,
            email: email,
            name: name,
            role: role || 'admin', // Use provided role or default to admin
            organizationId: newOrg._id
        });

        return { user: newUser, org: newOrg };
    },

    /**
     * Login to get the JWT
     */
    async login({ email, password }) {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
        });

        if (error) throw new Error(error.message);

        // Fetch the internal user to get the role
        const mongoUser = await User.findOne({ supabaseId: data.session.user.id });

        // Return the session + internal user details
        return {
            session: data.session,
            user: mongoUser
        };
    }
};
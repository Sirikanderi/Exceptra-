import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './auth/AuthProvider';
import { ProtectedRoute } from './auth/ProtectedRoute';
import { AuthLayout } from './layouts/AuthLayout';
import { DashboardLayout } from './layouts/DashboardLayout';

// Auth Pages
import { Login } from './pages/auth/Login';
import { Register } from './pages/auth/Register';

// Dashboard Pages
import { Overview } from './pages/dashboard/Overview';
import { Inventory } from './pages/dashboard/Inventory';
import { Forecasting } from './pages/dashboard/Forecasting';
import { Suppliers } from './pages/dashboard/Suppliers';
import { Logistics } from './pages/dashboard/Logistics';
import { BillingUpload } from './pages/dashboard/BillingUpload';
import { Reports } from './pages/dashboard/Reports';
import { Settings } from './pages/dashboard/Settings';

// Driver Pages
import { DriverLayout } from './layouts/DriverLayout';
import { DriverDashboard } from './pages/driver/DriverDashboard';
import { DriverMapPage } from './pages/driver/DriverMapPage';
import { DriverRouteUpdatePage } from './pages/driver/DriverRouteUpdatePage';
import { DriverDelivery, DriverHistory } from './pages/driver/DriverPages';

import { RootRedirect } from './auth/RootRedirect';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* Public Authentication Routes */}
          <Route path="/auth" element={<AuthLayout />}>
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route index element={<Navigate to="/auth/login" replace />} />
          </Route>

          {/* Protected Dashboard Routes - Shopkeeper & Supplier */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute allowedRoles={['shopkeeper', 'supplier', 'admin']}>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Overview />} />
            <Route path="inventory" element={<Inventory />} />
            <Route path="forecasting" element={<Forecasting />} />
            <Route path="suppliers" element={<Suppliers />} />
            <Route path="logistics" element={<Logistics />} />
            <Route path="billing" element={<BillingUpload />} />
            <Route path="reports" element={<Reports />} />
            <Route path="settings" element={<Settings />} />

          </Route>

          {/* Driver Portal Routes - Driver Only */}
          <Route path="/driver" element={
            <ProtectedRoute allowedRoles={['driver']}>
              <DriverLayout />
            </ProtectedRoute>
          }>
            <Route index element={<Navigate to="/driver/dashboard" replace />} />
            <Route path="dashboard" element={<DriverDashboard />} />
            <Route path="map" element={<DriverMapPage />} />
            <Route path="delivery" element={<DriverDelivery />} />
            <Route path="route-update" element={<DriverRouteUpdatePage />} />
            <Route path="history" element={<DriverHistory />} />
            <Route path="settings" element={<DriverDashboard />} /> {/* Placeholder */}
          </Route>

          {/* Root Redirect */}
          <Route path="/" element={<RootRedirect />} />

          {/* Fallback for 404 */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;

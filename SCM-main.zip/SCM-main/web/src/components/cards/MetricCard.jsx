import clsx from 'clsx';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export const MetricCard = ({
    title,
    value,
    trend,
    trendValue,
    icon: Icon,
    color = 'blue'
}) => {
    const colorStyles = {
        blue: 'bg-blue-50 text-blue-600',
        green: 'bg-green-50 text-green-600',
        red: 'bg-red-50 text-red-600',
        orange: 'bg-orange-50 text-orange-600',
        purple: 'bg-purple-50 text-purple-600',
    };

    const trendColors = {
        up: 'text-green-600',
        down: 'text-red-600',
        neutral: 'text-gray-500',
    };

    const TrendIcon = trend === 'up' ? ArrowUpRight : trend === 'down' ? ArrowDownRight : Minus;

    return (
        <div className="bg-white overflow-hidden rounded-xl border border-gray-100 shadow-sm transition-all hover:shadow-md">
            <div className="p-5">
                <div className="flex items-center">
                    <div className="flex-shrink-0">
                        <div className={clsx('h-12 w-12 rounded-lg flex items-center justify-center', colorStyles[color])}>
                            {Icon && <Icon className="h-6 w-6" />}
                        </div>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                        <dl>
                            <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
                            <dd>
                                <div className="text-2xl font-bold text-gray-900">{value}</div>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            {(trend || trendValue) && (
                <div className="bg-gray-50 px-5 py-3">
                    <div className="text-sm">
                        <span className={clsx('font-medium inline-flex items-center', trendColors[trend || 'neutral'])}>
                            <TrendIcon className="mr-1 h-4 w-4" />
                            {trendValue}
                        </span>
                        <span className="text-gray-500 ml-1">from last month</span>
                    </div>
                </div>
            )}
        </div>
    );
};

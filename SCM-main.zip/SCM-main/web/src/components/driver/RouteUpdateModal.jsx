import React, { useState } from 'react';
import { X, AlertTriangle, MapPin, Navigation } from 'lucide-react';

export const RouteUpdateModal = ({ isOpen, onClose, onSubmit, deliveryId, initialCoordinates }) => {
    const [reason, setReason] = useState('Traffic');
    const [notes, setNotes] = useState('');

    if (!isOpen) return null;

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit({
            deliveryId,
            reason,
            notes,
            coordinates: initialCoordinates
        });
        onClose();
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all animate-in fade-in zoom-in duration-200">
                {/* Header */}
                <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 text-white flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold flex items-center gap-2">
                            <Navigation className="w-5 h-5" />
                            Update Route
                        </h2>
                        <p className="text-blue-100 text-sm mt-1">Report a diversion or delay</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-1 hover:bg-white/20 rounded-full transition-colors"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Body */}
                <form onSubmit={handleSubmit} className="p-6 space-y-6">

                    {/* Location Info */}
                    <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                        <div className="flex items-start gap-3">
                            <div className="p-2 bg-blue-100 rounded-lg text-blue-600 shrink-0">
                                <MapPin className="w-5 h-5" />
                            </div>
                            <div>
                                <h3 className="font-semibold text-blue-900 text-sm">Diversion Point Selected</h3>
                                <p className="text-xs text-blue-700 mt-1 font-mono">
                                    Lat: {initialCoordinates?.lat.toFixed(6)}
                                    <br />
                                    Lng: {initialCoordinates?.lng.toFixed(6)}
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Reason Selection */}
                    <div className="space-y-2">
                        <label className="text-sm font-semibold text-gray-700">Reason for Change</label>
                        <div className="relative">
                            <select
                                value={reason}
                                onChange={(e) => setReason(e.target.value)}
                                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white font-medium text-gray-900 transition-all"
                            >
                                <option value="Accident">Accident</option>
                                <option value="Road Closed">Road Closed</option>
                                <option value="Traffic">Heavy Traffic</option>
                                <option value="Weather">Weather Conditions</option>
                                <option value="Other">Other</option>
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" /></svg>
                            </div>
                        </div>
                    </div>

                    {/* Notes */}
                    <div className="space-y-2">
                        <label className="text-sm font-semibold text-gray-700">Additional Notes</label>
                        <textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            placeholder="Describe the situation..."
                            rows="3"
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all resize-none"
                        />
                    </div>

                    {/* Warning */}
                    <div className="flex items-center gap-2 text-amber-600 bg-amber-50 px-3 py-2 rounded-lg text-xs">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>This update will recalculate ETA and notify the supplier.</span>
                    </div>

                    {/* Actions */}
                    <div className="pt-2">
                        <button
                            type="submit"
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-600/30 transform transition-all active:scale-[0.98] flex justify-center items-center gap-2"
                        >
                            <span>Confirm New Route</span>
                            <Navigation className="w-4 h-4" />
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

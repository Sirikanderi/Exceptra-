import { useState } from 'react';
import { X, AlertTriangle, CloudRain, Car, ShieldAlert } from 'lucide-react';

export const RouteChangeForm = ({ isOpen, onClose, onSubmit, deliveryId, initialCoordinates }) => {
    const [reason, setReason] = useState('');
    const [notes, setNotes] = useState('');
    const [coords, setCoords] = useState(initialCoordinates);
    const [loading, setLoading] = useState(false);

    if (!isOpen) return null;

    // Update local state when props change
    if (initialCoordinates && (!coords || coords.lat !== initialCoordinates.lat)) {
        setCoords(initialCoordinates);
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        // Simulate API delay needed? Layout handles it usually.
        await onSubmit({ reason, notes, deliveryId, coordinates: coords });
        setLoading(false);
        onClose();
    };

    const reasons = [
        { id: 'Accident', label: 'Accident', icon: ShieldAlert, color: 'text-red-600 bg-red-50' },
        { id: 'Road Blocked', label: 'Road Blocked', icon: AlertTriangle, color: 'text-orange-600 bg-orange-50' },
        { id: 'Traffic Jam', label: 'Traffic Jam', icon: Car, color: 'text-yellow-600 bg-yellow-50' },
        { id: 'Weather', label: 'Weather', icon: CloudRain, color: 'text-blue-600 bg-blue-50' },
        { id: 'Other', label: 'Other', icon: AlertTriangle, color: 'text-gray-600 bg-gray-50' }
    ];

    return (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-opacity">
            <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl transform transition-transform scale-100 p-6">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-gray-900">Report Route Change</h3>
                    <button onClick={onClose} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
                        <X className="w-5 h-5 text-gray-600" />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Coordinates Display */}
                    {coords && (
                        <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 flex items-center">
                            <div className="bg-blue-200 p-2 rounded-full mr-3">
                                <AlertTriangle className="w-4 h-4 text-blue-700" />
                            </div>
                            <div>
                                <p className="text-xs text-blue-800 font-semibold uppercase tracking-wider">Diversion Point</p>
                                <p className="text-sm font-mono text-blue-900">
                                    {coords.lat.toFixed(6)}, {coords.lng.toFixed(6)}
                                </p>
                            </div>
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-3">Reason for Change</label>
                        <div className="grid grid-cols-2 gap-3">
                            {reasons.map((r) => (
                                <button
                                    type="button"
                                    key={r.id}
                                    onClick={() => setReason(r.id)}
                                    className={`flex items-center p-3 rounded-xl border transition-all duration-200 ${reason === r.id
                                        ? 'border-blue-500 ring-2 ring-blue-200 bg-blue-50'
                                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                                        }`}
                                >
                                    <div className={`p-2 rounded-full mr-3 ${r.color}`}>
                                        <r.icon className="w-5 h-5" />
                                    </div>
                                    <span className="font-medium text-gray-900 text-sm">{r.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Additional Details (Optional)</label>
                        <textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            placeholder="Briefly explain (e.g., Police diversion, landslide...)"
                            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm min-h-[100px]"
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={!reason || loading}
                        className="w-full py-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform active:scale-95"
                    >
                        {loading ? 'Submitting...' : 'Submit Update'}
                    </button>
                </form>
            </div>
        </div>
    );
};

import { Clock, MapPin, Navigation } from 'lucide-react';
import clsx from 'clsx';
import { format } from 'date-fns';

export const RouteStatusCard = ({ route, status }) => {
    if (!route) return null;

    const isDelayed = status?.routeStatus === 'Delayed';

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-6">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <h2 className="text-xl font-bold text-gray-900">Current Delivery</h2>
                    <p className="text-sm text-gray-500 font-mono mt-1">{route.deliveryId}</p>
                </div>
                <span className={clsx(
                    "px-3 py-1 rounded-full text-sm font-bold uppercase tracking-wide",
                    isDelayed ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                )}>
                    {status?.routeStatus || 'On Time'}
                </span>
            </div>

            <div className="flex items-center justify-between relative py-4">
                {/* Timeline Line */}
                <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-gray-200 -z-10" />

                {/* Origin */}
                <div className="bg-white px-2 text-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-2 border-2 border-white shadow-sm">
                        <div className="w-3 h-3 bg-blue-600 rounded-full" />
                    </div>
                    <p className="text-sm font-bold text-gray-900">{route.origin}</p>
                    <p className="text-xs text-gray-500">Start</p>
                </div>

                {/* Destination */}
                <div className="bg-white px-2 text-center">
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center mx-auto mb-2 border-2 border-white shadow-sm">
                        <MapPin className="w-4 h-4 text-indigo-600" />
                    </div>
                    <p className="text-sm font-bold text-gray-900">{route.destination}</p>
                    <p className="text-xs text-gray-500">End</p>
                </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-2 gap-4">
                <div>
                    <p className="text-xs text-gray-500 mb-1 flex items-center">
                        <Clock className="w-3 h-3 mr-1" /> Estimated Arrival
                    </p>
                    <p className={clsx("text-lg font-bold", isDelayed ? "text-red-600" : "text-gray-900")}>
                        {status?.eta ? format(new Date(status.eta), 'h:mm a') : '--:--'}
                    </p>
                </div>
                <div>
                    <p className="text-xs text-gray-500 mb-1 flex items-center">
                        <Navigation className="w-3 h-3 mr-1" /> Distance Remaining
                    </p>
                    <p className="text-lg font-bold text-gray-900">
                        {route.distance || '0 km'}
                    </p>
                </div>
            </div>
        </div>
    );
};

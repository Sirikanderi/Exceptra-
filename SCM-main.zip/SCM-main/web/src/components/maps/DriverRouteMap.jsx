import { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import axios from 'axios';

export const DriverRouteMap = ({ originCoords, destinationCoords, oldRouteActive, onMapClick, diversionPoint }) => {
    const mapContainer = useRef(null);
    const map = useRef(null);
    const [zoom] = useState(6);
    const [center] = useState([75.8777, 20.0760]); // Centered between Nagpur and Mumbai
    const [mapLoaded, setMapLoaded] = useState(false);

    // Initial Map Setup
    useEffect(() => {
        if (map.current) return;

        map.current = new maplibregl.Map({
            container: mapContainer.current,
            style: {
                version: 8,
                sources: {
                    'osm-tiles': {
                        type: 'raster',
                        tiles: [
                            'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
                        ],
                        tileSize: 256,
                        attribution: '&copy; OpenStreetMap Contributors'
                    }
                },
                layers: [
                    {
                        id: 'osm-tiles-layer',
                        type: 'raster',
                        source: 'osm-tiles',
                        minzoom: 0,
                        maxzoom: 19
                    }
                ]
            },
            center: center,
            zoom: zoom
        });

        requestAnimationFrame(() => {
            if (map.current) {
                map.current.resize();
            }
        });

        // Add Navigation Control
        map.current.addControl(new maplibregl.NavigationControl(), 'top-right');

        // Click Handler (Diversion Selection)
        map.current.on('click', (e) => {
            if (onMapClick) {
                // Pass raw MapLibre event or normalized coords
                // MapLibre event has lngLat ({lng, lat})
                const normalizedEvent = {
                    latLng: {
                        lat: () => e.lngLat.lat,
                        lng: () => e.lngLat.lng
                    }
                };
                onMapClick(normalizedEvent);
            }
        });

        // Double Click Handler (Alternative)
        map.current.on('dblclick', (e) => {
            e.preventDefault(); // Prevent zoom
            if (onMapClick) {
                const normalizedEvent = {
                    latLng: {
                        lat: () => e.lngLat.lat,
                        lng: () => e.lngLat.lng
                    }
                };
                onMapClick(normalizedEvent);
            }
        });

        map.current.on('load', () => {
            setMapLoaded(true);
        });

    }, []);

    // Handle Diversion Marker
    useEffect(() => {
        if (!map.current || !mapLoaded) return;

        // Remove existing diversion markers if any (simple implementation: clear all markers? No, better track it)
        // For simplicity in this demo, we assume the parent handles the "marker" logic via overlays 
        // OR we add a MapLibre marker here. The requirement says "Marker is placed on map".

        // Let's use a class property to track the marker or find via DOM
        const existingMarker = document.getElementById('diversion-marker');
        if (existingMarker) existingMarker.remove();

        if (diversionPoint) {
            const el = document.createElement('div');
            el.id = 'diversion-marker';
            el.className = 'w-6 h-6 bg-red-600 rounded-full border-4 border-white shadow-lg pointer-events-none';

            new maplibregl.Marker({ element: el })
                .setLngLat([diversionPoint.lng, diversionPoint.lat])
                .addTo(map.current);
        }
    }, [diversionPoint, mapLoaded]);


    // Route Calculation & Rendering
    useEffect(() => {
        if (!map.current || !mapLoaded || !originCoords || !destinationCoords) return;

        const fetchRoute = async () => {
            try {
                const apiKey = import.meta.env.VITE_ORS_API_KEY;
                if (!apiKey) {
                    console.error("VITE_ORS_API_KEY is missing");
                    return;
                }

                // If Old Route Active (Diversion Confirmed)
                // We need TWO routes: Old (Dashed) and New (Solid)
                // But we don't store the "Old" coords history in this component.
                // Spec says: "Old route becomes dashed", "New route becomes bright blue" via "diversion point".

                // Let's assume:
                // If !oldRouteActive: Draw Start -> End (Solid Blue)
                // If oldRouteActive: Draw Start -> End (Dashed Grey) AND Start -> Diversion -> End (Solid Blue)

                // 1. Fetch Standard Route (Start -> End)
                // We always need this for the "Old Route" context
                const standardRouteRes = await axios.post(
                    'https://api.openrouteservice.org/v2/directions/driving-car/geojson',
                    {
                        coordinates: [originCoords, destinationCoords]
                    },
                    { headers: { 'Authorization': apiKey } }
                );
                const standardGeoJSON = standardRouteRes.data;

                // 2. Setup Layers
                const layers = map.current.getStyle().layers;
                const standardLayerId = 'route-standard';
                const newRouteLayerId = 'route-new';

                // Add Source for Standard Route
                if (!map.current.getSource('source-standard')) {
                    map.current.addSource('source-standard', {
                        type: 'geojson',
                        data: standardGeoJSON
                    });
                } else {
                    map.current.getSource('source-standard').setData(standardGeoJSON);
                }

                if (oldRouteActive) {
                    // --- OLD ROUTE (DASHED) ---
                    if (map.current.getLayer(standardLayerId)) map.current.removeLayer(standardLayerId);

                    map.current.addLayer({
                        id: standardLayerId,
                        type: 'line',
                        source: 'source-standard',
                        layout: {
                            'line-join': 'round',
                            'line-cap': 'round'
                        },
                        paint: {
                            'line-color': '#6B7280', // Gray
                            'line-width': 4,
                            'line-dasharray': [2, 2],
                            'line-opacity': 0.7
                        }
                    });

                    // --- NEW ROUTE (SOLID via Diversion) ---
                    if (diversionPoint) {
                        const diversionCoords = [diversionPoint.lng, diversionPoint.lat];
                        const newRouteRes = await axios.post(
                            'https://api.openrouteservice.org/v2/directions/driving-car/geojson',
                            {
                                coordinates: [originCoords, diversionCoords, destinationCoords]
                            },
                            { headers: { 'Authorization': apiKey } }
                        );
                        const newRouteGeoJSON = newRouteRes.data;

                        if (!map.current.getSource('source-new')) {
                            map.current.addSource('source-new', {
                                type: 'geojson',
                                data: newRouteGeoJSON
                            });
                        } else {
                            map.current.getSource('source-new').setData(newRouteGeoJSON);
                        }

                        if (!map.current.getLayer(newRouteLayerId)) {
                            map.current.addLayer({
                                id: newRouteLayerId,
                                type: 'line',
                                source: 'source-new',
                                layout: { 'line-join': 'round', 'line-cap': 'round' },
                                paint: {
                                    'line-color': '#2563EB', // Bright Blue
                                    'line-width': 6,
                                    'line-opacity': 1.0
                                }
                            });
                        }
                    }

                } else {
                    // --- NORMAL STATE (Solid Blue Standard) ---
                    if (map.current.getLayer(newRouteLayerId)) map.current.removeLayer(newRouteLayerId);

                    if (!map.current.getLayer(standardLayerId)) {
                        map.current.addLayer({
                            id: standardLayerId,
                            type: 'line',
                            source: 'source-standard',
                            layout: { 'line-join': 'round', 'line-cap': 'round' },
                            paint: {
                                'line-color': '#2563EB', // Blue
                                'line-width': 6
                            }
                        });
                    } else {
                        // Ensure it's solid blue
                        map.current.setPaintProperty(standardLayerId, 'line-color', '#2563EB');
                        map.current.setPaintProperty(standardLayerId, 'line-width', 6);
                        map.current.setPaintProperty(standardLayerId, 'line-dasharray', null); // Remove dash
                        map.current.setPaintProperty(standardLayerId, 'line-opacity', 1);
                    }
                }

                // Add Markers for Start/End
                // Clean up old markers
                document.querySelectorAll('.route-marker').forEach(el => el.remove());

                const createMarker = (coords, color) => {
                    const el = document.createElement('div');
                    el.className = 'route-marker w-4 h-4 rounded-full border-2 border-white shadow-md';
                    el.style.backgroundColor = color;
                    new maplibregl.Marker({ element: el })
                        .setLngLat(coords)
                        .addTo(map.current);
                };

                createMarker(originCoords, '#10B981'); // Green Start
                createMarker(destinationCoords, '#EF4444'); // Red End


            } catch (error) {
                console.error("Failed to fetch route:", error);
            }
        };

        fetchRoute();
    }, [mapLoaded, originCoords, destinationCoords, oldRouteActive, diversionPoint]);

    return (
        <div ref={mapContainer} className="w-full h-full rounded-xl" />
    );
};

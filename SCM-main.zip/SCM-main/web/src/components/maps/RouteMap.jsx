import { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import axios from 'axios';

export const RouteMap = ({ origin, destination, oldRouteActive }) => {
    // Note: origin/destination here might still be strings from legacy usage.
    // For this refactor, we will assume they can be resolved or default to the hardcoded demo coords 
    // if not passed as arrays. Ideally, the parent should pass coords.
    // For the demo, we'll map the strings 'Nagpur' and 'Mumbai' to coords or transparently handle it.

    // Hardcoded for demo parity if strings are passed
    const getCoords = (loc) => {
        if (Array.isArray(loc)) return loc;
        if (typeof loc === 'string') {
            if (loc.includes('Nagpur')) return [79.0882, 21.1458];
            if (loc.includes('Mumbai')) return [72.8777, 19.0760];
        }
        return [79.0882, 21.1458]; // Default
    };

    const originCoords = getCoords(origin);
    const destinationCoords = getCoords(destination);

    const mapContainer = useRef(null);
    const map = useRef(null);
    const [zoom] = useState(6);
    const [center] = useState([75.8777, 20.0760]);
    const [mapLoaded, setMapLoaded] = useState(false);

    useEffect(() => {
        if (map.current) return;

        map.current = new maplibregl.Map({
            container: mapContainer.current,
            style: {
                version: 8,
                sources: {
                    'osm-tiles': {
                        type: 'raster',
                        tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
                        tileSize: 256,
                        attribution: '&copy; OpenStreetMap Contributors'
                    }
                },
                layers: [
                    {
                        id: 'osm-tiles-layer',
                        type: 'raster',
                        source: 'osm-tiles',
                        minzoom: 0,
                        maxzoom: 19
                    }
                ]
            },
            center: center,
            zoom: zoom,
            interactive: true
        });

        // Add Fullscreen control for Supplier view
        map.current.addControl(new maplibregl.FullscreenControl());
        map.current.addControl(new maplibregl.NavigationControl());

        // Wait for load
        map.current.on('load', () => setMapLoaded(true));
    }, []);

    // Draw Routes
    useEffect(() => {
        if (!map.current || !mapLoaded || !originCoords || !destinationCoords) return;

        const fetchRoutes = async () => {
            try {
                const apiKey = import.meta.env.VITE_ORS_API_KEY;
                if (!apiKey) return;

                // Always fetch standard route first
                const standardRes = await axios.post(
                    'https://api.openrouteservice.org/v2/directions/driving-car/geojson',
                    { coordinates: [originCoords, destinationCoords] },
                    { headers: { 'Authorization': apiKey } }
                );
                const standardGeoJSON = standardRes.data;

                const standardSourceId = 'source-std';
                const standardLayerId = 'layer-std';
                const newSourceId = 'source-new';
                const newLayerId = 'layer-new';

                // Standard Route Source
                if (!map.current.getSource(standardSourceId)) {
                    map.current.addSource(standardSourceId, { type: 'geojson', data: standardGeoJSON });
                } else {
                    map.current.getSource(standardSourceId).setData(standardGeoJSON);
                }

                if (oldRouteActive) {
                    // DIVERSIFIED STATE
                    // 1. Old Route as Dashed
                    if (map.current.getLayer(standardLayerId)) map.current.removeLayer(standardLayerId);
                    map.current.addLayer({
                        id: standardLayerId,
                        type: 'line',
                        source: standardSourceId,
                        layout: { 'line-join': 'round', 'line-cap': 'round' },
                        paint: {
                            'line-color': '#9CA3AF',
                            'line-width': 4,
                            'line-dasharray': [2, 2],
                            'line-opacity': 0.6
                        }
                    });

                    // 2. New Route (Simulated via a Diversion Point for demo visual)
                    // Since the supplier view receives `oldRouteActive` but might not have the EXACT diversion point 
                    // passed in props (unless we update logic), we will simulate a diversion point 
                    // roughly similar to the driver's default choice or fetch "actual" route if backend provided it.
                    // For this refactor, we'll pick a fixed diversion point near the middle to visualize the "New" route.
                    // Diversion: Aurangabad [75.3433, 19.8762]

                    const diversionCoords = [75.3433, 19.8762];
                    const newRes = await axios.post(
                        'https://api.openrouteservice.org/v2/directions/driving-car/geojson',
                        { coordinates: [originCoords, diversionCoords, destinationCoords] },
                        { headers: { 'Authorization': apiKey } }
                    );
                    const newGeoJSON = newRes.data;

                    if (!map.current.getSource(newSourceId)) {
                        map.current.addSource(newSourceId, { type: 'geojson', data: newGeoJSON });
                    } else {
                        map.current.getSource(newSourceId).setData(newGeoJSON);
                    }

                    if (!map.current.getLayer(newLayerId)) {
                        map.current.addLayer({
                            id: newLayerId,
                            type: 'line',
                            source: newSourceId,
                            layout: { 'line-join': 'round', 'line-cap': 'round' },
                            paint: {
                                'line-color': '#2563EB',
                                'line-width': 6
                            }
                        });
                    }

                } else {
                    // STANDARD STATE
                    if (map.current.getLayer(newLayerId)) map.current.removeLayer(newLayerId);

                    if (!map.current.getLayer(standardLayerId)) {
                        map.current.addLayer({
                            id: standardLayerId,
                            type: 'line',
                            source: standardSourceId,
                            layout: { 'line-join': 'round', 'line-cap': 'round' },
                            paint: {
                                'line-color': '#2563EB',
                                'line-width': 6
                            }
                        });
                    } else {
                        map.current.setPaintProperty(standardLayerId, 'line-color', '#2563EB');
                        map.current.setPaintProperty(standardLayerId, 'line-width', 6);
                        map.current.setPaintProperty(standardLayerId, 'line-dasharray', null);
                        map.current.setPaintProperty(standardLayerId, 'line-opacity', 1);
                    }
                }

                // Markers
                document.querySelectorAll('.map-marker').forEach(el => el.remove());
                const addMarker = (coords, color) => {
                    const el = document.createElement('div');
                    el.className = 'map-marker w-4 h-4 rounded-full border-2 border-white shadow-sm';
                    el.style.backgroundColor = color;
                    new maplibregl.Marker({ element: el }).setLngLat(coords).addTo(map.current);
                }
                addMarker(originCoords, '#10B981');
                addMarker(destinationCoords, '#EF4444');

            } catch (e) {
                console.error("Map route error", e);
            }
        };

        fetchRoutes();

    }, [mapLoaded, originCoords, destinationCoords, oldRouteActive]);

    return (
        <div ref={mapContainer} className="w-full h-full rounded-xl border border-gray-200" />
    );
};

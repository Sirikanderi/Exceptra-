import { Bot, AlertTriangle, Info } from 'lucide-react';
import clsx from 'clsx';

export const AIExplanationPanel = ({ explanation, type = 'info', visible }) => {
    if (!visible) return null;

    return (
        <div className={clsx(
            "rounded-xl p-4 border shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-500",
            type === 'warning' ? "bg-amber-50 border-amber-200" : "bg-blue-50 border-blue-200"
        )}>
            <div className="flex items-start space-x-3">
                <div className={clsx(
                    "p-2 rounded-lg shrink-0",
                    type === 'warning' ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700"
                )}>
                    <Bot className="w-6 h-6" />
                </div>
                <div className="flex-1">
                    <h4 className={clsx(
                        "font-bold text-sm mb-1 uppercase tracking-wide",
                        type === 'warning' ? "text-amber-800" : "text-blue-800"
                    )}>
                        AI Insight
                    </h4>
                    <p className="text-gray-800 text-sm leading-relaxed">
                        {explanation || "Analyzing route conditions..."}
                    </p>
                </div>
            </div>
        </div>
    );
};

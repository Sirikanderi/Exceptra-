import { useState, useRef } from 'react';
import { UploadCloud, File, X, CheckCircle } from 'lucide-react';
import clsx from 'clsx';
import { Button } from '../common/Button';

export const FileUpload = ({ onUpload, acceptedFileTypes = '.csv', isLoading, buttonLabel }) => {
    const [dragActive, setDragActive] = useState(false);
    const [file, setFile] = useState(null);
    const inputRef = useRef(null);

    const handleDrag = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'dragenter' || e.type === 'dragover') {
            setDragActive(true);
        } else if (e.type === 'dragleave') {
            setDragActive(false);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            setFile(e.dataTransfer.files[0]);
        }
    };

    const handleChange = (e) => {
        e.preventDefault();
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleSubmit = () => {
        if (file) {
            onUpload(file);
        }
    };

    return (
        <div className="w-full max-w-xl mx-auto">
            <div
                className={clsx(
                    "relative border-2 border-dashed rounded-xl p-8 text-center transition-colors",
                    dragActive ? "border-blue-500 bg-blue-50" : "border-gray-300 bg-gray-50",
                    isLoading ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:bg-gray-100"
                )}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                onClick={() => !file && inputRef.current.click()}
            >
                <input
                    ref={inputRef}
                    type="file"
                    className="hidden"
                    accept={acceptedFileTypes}
                    onChange={handleChange}
                    disabled={isLoading || file}
                />

                {!file ? (
                    <div className="space-y-2">
                        <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
                        <p className="text-lg font-medium text-gray-700">
                            Drag & Drop your CSV file here
                        </p>
                        <p className="text-sm text-gray-500">
                            or click to browse
                        </p>
                    </div>
                ) : (
                    <div className="flex flex-col items-center">
                        <div className="bg-blue-100 p-3 rounded-full mb-3">
                            <File className="h-8 w-8 text-blue-600" />
                        </div>
                        <p className="font-medium text-gray-900">{file.name}</p>
                        <p className="text-xs text-gray-500 mt-1">{(file.size / 1024).toFixed(2)} KB</p>

                        {!isLoading && (
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setFile(null);
                                }}
                                className="mt-4 text-red-600 text-sm font-medium hover:text-red-700 flex items-center"
                            >
                                <X className="h-4 w-4 mr-1" />
                                Remove File
                            </button>
                        )}
                    </div>
                )}
            </div>

            {file && (
                <div className="mt-6 flex justify-end">
                    <Button onClick={handleSubmit} isLoading={isLoading} disabled={isLoading}>
                        {isLoading ? 'Uploading...' : (buttonLabel || 'Upload File')}
                    </Button>
                </div>
            )}
        </div>
    );
};

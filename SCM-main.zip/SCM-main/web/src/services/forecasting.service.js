import http from './http';
import { API_ENDPOINTS } from '../config/api.config';

export const forecastingService = {
    uploadHistory: async (file) => {
        const formData = new FormData();
        formData.append('file', file);

        const response = await http.post(API_ENDPOINTS.FORECASTING.UPLOAD, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response.data;
    },

    async uploadMarketData(file) {
        const formData = new FormData();
        formData.append('file', file);
        // We need to add this endpoint to API_CONFIG first or just use raw string if config is tight
        // Let's assume we add it to config, or just hardcode for speed now then refactor
        const response = await http.post('/forecasting/upload-market-data', formData);
        return response.data;
    },

    async getSkus() {
        const response = await http.get('/forecasting/skus');
        return response.data;
    },

    getForecast: async (sku) => {
        const response = await http.get(API_ENDPOINTS.FORECASTING.PREDICT(sku));
        return response.data;
    }
};

import http from '../services/http';
import { API_ENDPOINTS } from '../config/api.config';

export const authService = {
    login: async (credentials) => {
        const response = await http.post(API_ENDPOINTS.AUTH.LOGIN, credentials);
        return response.data;
    },

    register: async (userData) => {
        const response = await http.post(API_ENDPOINTS.AUTH.REGISTER, userData);
        return response.data;
    },

    getCurrentUser: async () => {
        const response = await http.get(API_ENDPOINTS.AUTH.ME);
        return response.data;
    },

    logout: () => {
        localStorage.removeItem('scm_token');
        localStorage.removeItem('scm_user');
    }
};

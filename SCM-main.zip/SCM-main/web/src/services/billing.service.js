import http from './http';
import { API_ENDPOINTS } from '../config/api.config';

export const billingService = {
    uploadCsv: async (file, onProgress) => {
        const formData = new FormData();
        formData.append('file', file);

        const response = await http.post(API_ENDPOINTS.BILLING.UPLOAD, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
            onUploadProgress: (progressEvent) => {
                const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                if (onProgress) onProgress(percentCompleted);
            },
        });
        return response.data;
    }
};

import http from './http';
import { API_ENDPOINTS } from '../config/api.config';

export const suppliersService = {
    getAll: async () => {
        try {
            const response = await http.get(API_ENDPOINTS.SUPPLIERS.LIST);
            return response.data;
        } catch (error) {
            console.error('Error fetching suppliers:', error);
            throw error;
        }
    },

    addSupplier: async (supplierData) => {
        const response = await http.post(API_ENDPOINTS.SUPPLIERS.ADD, supplierData);
        return response.data;
    },

    deleteSupplier: async (id) => {
        const response = await http.delete(API_ENDPOINTS.SUPPLIERS.DELETE(id));
        return response.data;
    }
};

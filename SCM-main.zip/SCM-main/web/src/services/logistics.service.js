import http from './http';
import { API_ENDPOINTS } from '../config/api.config';

export const logisticsService = {
    getShipments: async () => {
        try {
            const response = await http.get(API_ENDPOINTS.LOGISTICS.SHIPMENTS);
            return response.data;
        } catch (error) {
            console.error('Error fetching shipments:', error);
            throw error;
        }
    },

    createShipment: async (shipmentData) => {
        const response = await http.post(API_ENDPOINTS.LOGISTICS.CREATE, shipmentData);
        return response.data;
    }
};

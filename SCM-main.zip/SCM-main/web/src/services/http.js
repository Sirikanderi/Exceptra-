import axios from 'axios';
import { env } from '../config/env.config';

const http = axios.create({
    baseURL: env.API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    timeout: 300000, // 5 minutes timeout for large files/AI ops
});

// Request interceptor to add auth token
http.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('scm_token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor for handling errors
http.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response && error.response.status === 401) {
            // Handle unauthorized access (e.g., clear token and redirect)
            // localStorage.removeItem('scm_token'); // TEMPORARILY DISABLED TO DEBUD
            console.error("401 Unauthorized - Check backend logs");
            // window.location.href = '/auth/login'; // Optional: Force redirect
        }
        return Promise.reject(error);
    }
);

export default http;

import http from './http';
import { API_ENDPOINTS } from '../config/api.config';

export const analyticsService = {
    getDashboardStats: async () => {
        try {
            const response = await http.get(API_ENDPOINTS.ANALYTICS.DASHBOARD);
            return response.data;
        } catch (error) {
            console.error('Failed to fetch dashboard stats', error);
            throw error;
        }
    }
};

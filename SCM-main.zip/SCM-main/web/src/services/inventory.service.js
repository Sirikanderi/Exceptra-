import http from './http';
import { API_ENDPOINTS } from '../config/api.config';

export const inventoryService = {
    // Get all inventory items
    getAll: async () => {
        try {
            const response = await http.get(API_ENDPOINTS.INVENTORY.LIST);
            return response.data;
        } catch (error) {
            console.error('Error fetching inventory:', error);
            throw error;
        }
    },

    // Get single item details
    getById: async (id) => {
        const response = await http.get(API_ENDPOINTS.INVENTORY.DETAILS(id));
        return response.data;
    },

    // Add new item
    addItem: async (itemData) => {
        const response = await http.post(API_ENDPOINTS.INVENTORY.ADD, itemData);
        return response.data;
    },

    // Import from XLSX
    importInventory: async (file) => {
        const formData = new FormData();
        formData.append('file', file);
        const response = await http.post(API_ENDPOINTS.INVENTORY.IMPORT, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    }
};

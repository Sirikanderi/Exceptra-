import { env } from './env.config';

export const API_ENDPOINTS = {
    AUTH: {
        LOGIN: '/auth/login',
        REGISTER: '/auth/register',
        ME: '/auth/me',
    },
    INVENTORY: {
        LIST: '/inventory',
        ADD: '/inventory/add',
        IMPORT: '/inventory/import',
        DETAILS: (id) => `/inventory/${id}`,
    },
    BILLING: {
        UPLOAD: '/billing/upload',
    },
    FORECASTING: {
        DEMAND: (sku) => `/forecasting/${sku}`,
    },
    SUPPLIERS: {
        LIST: '/suppliers',
        ADD: '/suppliers/add',
        DELETE: (id) => `/suppliers/${id}`,
    },
    LOGISTICS: {
        SHIPMENTS: '/logistics',
        CREATE: '/logistics/create',
        UPDATE: (id) => `/logistics/${id}/update`,
    },
    ANALYTICS: {
        DASHBOARD: '/analytics/dashboard'
    },
    FORECASTING: {
        UPLOAD: '/forecasting/upload-history',
        PREDICT: (sku) => `/forecasting/predict/${sku}`
    }
};

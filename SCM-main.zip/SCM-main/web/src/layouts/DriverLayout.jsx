import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { Navigation, Truck, LogOut, Bell, User, Clock, Map, FileText, Settings, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../auth/useAuth';

export const DriverLayout = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const navItems = [
        { path: '/driver/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
        { path: '/driver/delivery', icon: Truck, label: 'Active Delivery' },
        { path: '/driver/map', icon: Map, label: 'Route Map' },
        { path: '/driver/route-update', icon: Navigation, label: 'Route Updates' },
        { path: '/driver/history', icon: FileText, label: 'History' },
        { path: '/driver/settings', icon: Settings, label: 'Settings' },
    ];

    return (
        <div className="flex bg-gray-50 h-screen w-full overflow-hidden font-sans">
            {/* Sidebar - Fixed Left */}
            <div className="w-64 bg-slate-900 text-white flex flex-col shrink-0 transition-all duration-300">
                {/* Logo Area */}
                <div className="h-16 flex items-center px-6 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                        <div className="bg-blue-600 p-1.5 rounded-lg shadow-lg shadow-blue-900/50">
                            <Navigation className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-lg font-bold leading-none tracking-tight">SCM PRO</h1>
                            <p className="text-[10px] text-gray-400 font-medium tracking-wider uppercase mt-0.5">Driver Portal</p>
                        </div>
                    </div>
                </div>

                {/* Navigation */}
                <nav className="flex-1 px-3 py-6 space-y-1 overflow-y-auto">
                    <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Menu</p>
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) => `
                                flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                                ${isActive
                                    ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                                    : 'text-gray-400 hover:bg-slate-800 hover:text-white'
                                }
                            `}
                        >
                            <item.icon className="w-5 h-5" />
                            <span>{item.label}</span>
                        </NavLink>
                    ))}
                </nav>

                {/* User / Logout */}
                <div className="p-4 border-t border-slate-800 bg-slate-900/50">
                    <div className="flex items-center gap-3 mb-4 px-2">
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center border border-slate-600">
                            <User className="w-4 h-4 text-gray-300" />
                        </div>
                        <div className="overflow-hidden">
                            <p className="text-sm font-medium text-white truncate">{user?.name || 'Driver User'}</p>
                            <p className="text-xs text-gray-500 truncate">ID: {user?.id || 'DRV-1024'}</p>
                        </div>
                    </div>
                    <button
                        onClick={logout}
                        className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg border border-slate-700 text-gray-400 hover:bg-slate-800 hover:text-white hover:border-slate-600 transition-all text-sm font-medium"
                    >
                        <LogOut className="w-4 h-4" />
                        Logout
                    </button>
                </div>
            </div>

            {/* Main Content Wrapper */}
            <div className="flex-1 flex flex-col h-full min-w-0 bg-gray-50/50">
                {/* Top Header */}
                <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0 shadow-sm z-10">
                    <div className="flex items-center text-gray-800">
                        {/* Breadcrumb placeholder or Page Title could go here */}
                        <span className="text-gray-400">Portal</span>
                        <span className="mx-2 text-gray-300">/</span>
                        <span className="font-semibold text-gray-700">Dashboard</span>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="h-8 w-px bg-gray-200 mx-1"></div>
                        <button className="relative p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors">
                            <Bell className="w-5 h-5" />
                            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white"></span>
                        </button>
                        <div className="flex items-center gap-3 pl-2">
                            <img
                                src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix"
                                alt="Profile"
                                className="w-9 h-9 rounded-full border border-gray-200 bg-gray-50"
                            />
                        </div>
                    </div>
                </header>

                {/* Page Content */}
                <main className="flex-1 overflow-hidden relative">
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

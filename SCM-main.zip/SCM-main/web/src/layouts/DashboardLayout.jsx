import { Outlet } from 'react-router-dom';
import { Sidebar } from '../components/navigation/Sidebar';
import { Topbar } from '../components/navigation/Topbar';

export const DashboardLayout = () => {
    return (
        <div className="flex h-screen bg-gray-50 overflow-hidden">
            {/* Sidebar - Hidden on mobile, typically controlled by toggle in production */}
            <div className="hidden md:flex md:flex-shrink-0">
                <Sidebar />
            </div>

            <div className="flex flex-col w-0 flex-1 overflow-hidden">
                <Topbar />

                <main className="flex-1 relative overflow-y-auto focus:outline-none">
                    <div className="py-6">
                        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
                            <Outlet />
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
};

import { Navigate } from 'react-router-dom';
import { useAuth } from './useAuth';

export const RootRedirect = () => {
    const { user, loading } = useAuth();

    if (loading) {
        return <div className="h-screen w-full flex items-center justify-center">Loading...</div>;
    }

    if (!user) {
        return <Navigate to="/auth/login" replace />;
    }

    if (user.role === 'driver') {
        return <Navigate to="/driver" replace />;
    }

    return <Navigate to="/dashboard" replace />;
};

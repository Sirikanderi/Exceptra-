import { Package, Truck, AlertTriangle, TrendingUp, Cpu } from 'lucide-react';
import { MetricCard } from '../../components/cards/MetricCard';
import { analyticsService } from '../../services/analytics.service';
import { useState, useEffect } from 'react';

export const Overview = () => {
    const [metricsData, setMetricsData] = useState({
        totalInventory: 0,
        totalValue: 0,
        pendingDeliveries: 0,
        stockoutRisk: 0
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const data = await analyticsService.getDashboardStats();
                setMetricsData(data);
            } catch (error) {
                console.error("Failed to load dashboard stats", error);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, []);

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 0
        }).format(value);
    };

    const metrics = [
        {
            title: 'Total Inventory',
            value: metricsData.totalInventory.toLocaleString(),
            trend: 'up', // Dynamic trend logic could be added later
            trendValue: '+12%', // a placeholder for now
            icon: Package,
            color: 'blue'
        },
        {
            title: 'Pending Deliveries',
            value: metricsData.pendingDeliveries.toString(),
            trend: 'down',
            trendValue: '4%',
            icon: Truck,
            color: 'orange'
        },
        {
            title: 'Stockout Risk',
            value: `${metricsData.stockoutRisk} Items`,
            trend: 'down',
            trendValue: 'Critical',
            icon: AlertTriangle,
            color: 'red'
        },
        {
            title: 'Inventory Value', // Changed from "Monthly Revenue" to match data we actually have
            value: formatCurrency(metricsData.totalValue),
            trend: 'up',
            trendValue: '8.2%',
            icon: TrendingUp,
            color: 'green'
        }
    ];

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
                <button className="bg-white border border-gray-300 shadow-sm text-gray-700 text-sm font-medium py-2 px-4 rounded-lg hover:bg-gray-50">
                    Download Report
                </button>
            </div>

            {/* AI Insight Section */}
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
                <div className="flex items-start space-x-4">
                    <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
                        <Cpu className="h-6 w-6 text-white" />
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold mb-1">AI Daily Insight</h3>
                        <p className="text-indigo-100 leading-relaxed">
                            Demand for "Steel Rods" is predicted to increase by 25% next week due to seasonal construction trends.
                            Consider increasing safety stock at the North Warehouse to prevent stockouts.
                        </p>
                    </div>
                </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                {metrics.map((metric, index) => (
                    <MetricCard key={index} {...metric} />
                ))}
            </div>

            {/* Placeholder for Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm min-h-[300px] flex items-center justify-center">
                    <p className="text-gray-400 font-medium">Demand Forecast Chart (Coming Soon)</p>
                </div>
                <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm min-h-[300px] flex items-center justify-center">
                    <p className="text-gray-400 font-medium">Inventory Distribution (Coming Soon)</p>
                </div>
            </div>
        </div>
    );
};

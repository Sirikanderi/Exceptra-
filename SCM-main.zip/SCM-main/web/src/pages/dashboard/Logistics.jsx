import { useState, useEffect } from 'react';
import { DataTable } from '../../components/tables/DataTable';
import { RouteMap } from '../../components/maps/RouteMap';
import { logisticsService } from '../../services/logistics.service';
import { AIExplanationPanel } from '../../components/dashboard/AIExplanationPanel';
import clsx from 'clsx';
import { Truck, MapPin, Clock } from 'lucide-react';

export const Logistics = () => {
    const [shipments, setShipments] = useState([]);
    const [loading, setLoading] = useState(true);
    // Demo state for map visualization
    const [activeRoute, setActiveRoute] = useState({
        origin: 'Nagpur, Maharashtra',
        destination: 'Mumbai, Maharashtra',
        oldRouteActive: false
    });
    const [explanation, setExplanation] = useState(null);

    useEffect(() => {
        loadShipments();
        // Polling simulation for "Real-time" updates
        const interval = setInterval(() => {
            loadShipments(true);
        }, 5000);

        return () => clearInterval(interval);
    }, []);

    const loadShipments = async (silent = false) => {
        try {
            if (!silent) setLoading(true);
            const data = await logisticsService.getShipments();
            setShipments(data);

            // Check for specific dummy data tracking ID or just the first delayed one
            // In a real app, 'activeRoute' would be selected from the table
            const delayedShipment = data.find(s => s.status === 'Delayed');
            if (delayedShipment) {
                // Trigger UI updates for the demo if we see a delayed shipment
                setActiveRoute(prev => ({ ...prev, oldRouteActive: true }));
                // Determine explanation text - normally from backend
                const reason = delayedShipment.reason || 'Road Blocked'; // fallback
                setExplanation(`Delivery ${delayedShipment.id} was delayed due to ${reason}. The driver reported this at ${new Date().toLocaleTimeString()}. ETA has been updated.`);
            }

        } catch (error) {
            console.error(error);
        } finally {
            if (!silent) setLoading(false);
        }
    };

    const columns = [
        { key: 'id', header: 'Tracking ID', render: (row) => <span className="font-mono text-xs font-semibold bg-gray-100 px-2 py-1 rounded text-gray-600">{row.id}</span> },
        {
            key: 'route', header: 'Route', render: (row) => (
                <div className="flex items-center space-x-2 text-sm">
                    <span className="font-medium text-gray-900">{row.origin}</span>
                    <span className="text-gray-400">→</span>
                    <span className="font-medium text-gray-900">{row.destination}</span>
                </div>
            )
        },
        { key: 'driver', header: 'Driver' },
        {
            key: 'eta', header: 'ETA', render: (row) => (
                <div className="flex items-center text-gray-500 text-sm">
                    <Clock className="h-3 w-3 mr-1" />
                    {row.eta}
                </div>
            )
        },
        {
            key: 'status', header: 'Status', render: (row) => {
                const styles = {
                    'In Transit': 'bg-blue-100 text-blue-800',
                    'Delivered': 'bg-green-100 text-green-800',
                    'Delayed': 'bg-red-100 text-red-800'
                };
                return (
                    <span className={clsx("px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full", styles[row.status])}>
                        {row.status}
                    </span>
                );
            }
        }
    ];

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Logistics & Shipments</h1>
                    <p className="mt-1 text-sm text-gray-500">Real-time fleet tracking and route optimization.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    {/* Live Map Section */}
                    <div className="bg-white p-1 rounded-xl border border-gray-200 shadow-sm relative">
                        <RouteMap
                            origin={activeRoute.origin}
                            destination={activeRoute.destination}
                            oldRouteActive={activeRoute.oldRouteActive}
                        />

                        {/* AI Overlay */}
                        <div className="absolute top-4 left-4 right-4 z-10">
                            <AIExplanationPanel
                                visible={!!explanation}
                                explanation={explanation}
                                type="warning"
                            />
                        </div>
                    </div>

                    {/* Shipments Table */}
                    {loading ? (
                        <div className="h-32 flex items-center justify-center">
                            <div className="h-6 w-6 animate-spin rounded-full border-2 border-blue-600 border-t-transparent"></div>
                        </div>
                    ) : (
                        <DataTable
                            title="Active Shipments"
                            columns={columns}
                            data={shipments}
                            pagination={false}
                        />
                    )}
                </div>

                {/* Sidebar Info / Fleet Status */}
                <div className="lg:col-span-1 space-y-6">
                    <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                        <h3 className="text-lg font-semibold text-gray-900 mb-4">Fleet Status</h3>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                <div className="flex items-center">
                                    <div className="p-2 bg-green-100 rounded-lg mr-3">
                                        <Truck className="h-5 w-5 text-green-600" />
                                    </div>
                                    <span className="font-medium text-gray-700">Available</span>
                                </div>
                                <span className="text-xl font-bold text-gray-900">8</span>
                            </div>
                            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                <div className="flex items-center">
                                    <div className="p-2 bg-blue-100 rounded-lg mr-3">
                                        <MapPin className="h-5 w-5 text-blue-600" />
                                    </div>
                                    <span className="font-medium text-gray-700">En Route</span>
                                </div>
                                <span className="text-xl font-bold text-gray-900">12</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

import { useState, useEffect } from 'react';
import { DataTable } from '../../components/tables/DataTable';
import { suppliersService } from '../../services/suppliers.service';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import { Plus, Mail, Trash2 } from 'lucide-react';
import clsx from 'clsx';

export const Suppliers = () => {
    const [suppliers, setSuppliers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        contact: '',
        email: '',
        category: '',
        address: ''
    });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        loadSuppliers();
    }, []);

    const loadSuppliers = async () => {
        try {
            setLoading(true);
            const data = await suppliersService.getAll();
            setSuppliers(data);
        } catch (error) {
            console.error('Failed to load suppliers', error);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await suppliersService.addSupplier(formData);
            setIsModalOpen(false);
            setFormData({ name: '', contact: '', email: '', category: '', address: '' });
            loadSuppliers(); // Refresh list
        } catch (error) {
            console.error('Failed to add supplier', error);
            alert('Failed to add supplier. Please check if email is unique.');
        } finally {
            setSubmitting(false);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this supplier?')) {
            try {
                await suppliersService.deleteSupplier(id);
                loadSuppliers();
            } catch (error) {
                console.error('Failed to delete supplier', error);
            }
        }
    };

    const columns = [
        { key: 'name', header: 'Supplier Name', render: (row) => <span className="font-semibold text-gray-900">{row.name}</span> },
        { key: 'category', header: 'Category' },
        {
            key: 'contact', header: 'Contact', render: (row) => (
                <div className="flex flex-col text-sm">
                    <div className="flex items-center text-gray-500">
                        <Mail className="h-3 w-3 mr-1" />
                        {row.email}
                    </div>
                    <span className="text-gray-400 text-xs">{row.contact}</span>
                </div>
            )
        },
        {
            key: 'rating', header: 'Rating', render: (row) => (
                <div className="flex items-center">
                    <span className={clsx(
                        "font-bold mr-1",
                        row.rating >= 4.5 ? "text-green-600" : row.rating >= 4.0 ? "text-blue-600" : "text-yellow-600"
                    )}>{row.rating || 0}</span>
                    <span className="text-xs text-gray-400">/ 5.0</span>
                </div>
            )
        },
        {
            key: 'status', header: 'Status', render: (row) => (
                <span className={clsx(
                    "px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full",
                    row.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                )}>
                    {row.status}
                </span>
            )
        },
        {
            key: 'actions', header: 'Actions', render: (row) => (
                <button onClick={() => handleDelete(row._id)} className="text-red-500 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                </button>
            )
        }
    ];

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Supplier Network</h1>
                    <p className="mt-1 text-sm text-gray-500">Manage relationships and performance.</p>
                </div>
                <Button onClick={() => setIsModalOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Supplier
                </Button>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent"></div>
                </div>
            ) : (
                <DataTable
                    title="Active Suppliers"
                    columns={columns}
                    data={suppliers}
                />
            )}

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title="Add New Supplier"
                footer={
                    <>
                        <Button
                            type="submit"
                            form="add-supplier-form"
                            className="ml-3"
                            isLoading={submitting}
                        >
                            Add Supplier
                        </Button>
                        <Button
                            variant="secondary"
                            onClick={() => setIsModalOpen(false)}
                        >
                            Cancel
                        </Button>
                    </>
                }
            >
                <form id="add-supplier-form" onSubmit={handleSubmit} className="space-y-4">
                    <Input
                        id="name"
                        label="Company Name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        placeholder="Acme Supplies Inc."
                    />
                    <Input
                        id="email"
                        label="Email Address"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        placeholder="contact@acme.com"
                    />
                    <Input
                        id="contact"
                        label="Phone Number"
                        value={formData.contact}
                        onChange={handleInputChange}
                        required
                        placeholder="+1 234 567 890"
                    />
                    <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                        <select
                            id="category"
                            value={formData.category}
                            onChange={handleInputChange}
                            className="block w-full rounded-lg border-gray-300 border shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2.5"
                            required
                        >
                            <option value="">Select Category</option>
                            <option value="Raw Material">Raw Material</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Packaging">Packaging</option>
                            <option value="Logistics">Logistics</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <Input
                        id="address"
                        label="Address"
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="123 Industrial Park, City"
                    />
                </form>
            </Modal>
        </div>
    );
};

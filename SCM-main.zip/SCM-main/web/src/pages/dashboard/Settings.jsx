import { useAuth } from '../../auth/useAuth';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { User, Bell, Shield, LogOut } from 'lucide-react';

export const Settings = () => {
    const { user, logout } = useAuth();

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Account Settings</h1>

            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-100">
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                        <User className="h-5 w-5 mr-2 text-gray-400" />
                        Profile Information
                    </h2>
                    <p className="mt-1 text-sm text-gray-500">Update your personal details and role.</p>
                </div>
                <div className="p-6 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Input label="Full Name" defaultValue={user?.name || 'Admin User'} />
                        <Input label="Email Address" defaultValue={user?.email || 'admin@scm.com'} type="email" />
                        <Input label="Role" defaultValue={user?.role || 'Manager'} disabled className="bg-gray-50 text-gray-500" />
                        <Input label="Organization" defaultValue="Acme Corp" />
                    </div>
                </div>
                <div className="px-6 py-4 bg-gray-50 text-right">
                    <Button>Save Changes</Button>
                </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-100">
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                        <Bell className="h-5 w-5 mr-2 text-gray-400" />
                        Notifications
                    </h2>
                </div>
                <div className="p-6 space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <h4 className="text-sm font-medium text-gray-900">Low Stock Alerts</h4>
                            <p className="text-sm text-gray-500">Get notified when inventory drops below reorder level.</p>
                        </div>
                        <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                            <input type="checkbox" name="toggle" id="toggle1" className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer border-blue-600 translate-x-4" />
                            <label htmlFor="toggle1" className="toggle-label block overflow-hidden h-6 rounded-full bg-blue-600 cursor-pointer"></label>
                        </div>
                    </div>
                </div>
            </div>

            <div className="flex justify-end">
                <button
                    onClick={logout}
                    className="flex items-center text-red-600 hover:text-red-700 font-medium px-4 py-2 rounded-lg hover:bg-red-50 transition-colors"
                >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                </button>
            </div>
        </div>
    );
};

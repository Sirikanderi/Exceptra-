import { useState, useEffect, useRef } from 'react';
import { DataTable } from '../../components/tables/DataTable';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Modal } from '../../components/common/Modal';
import { Plus, Filter, Download, Upload } from 'lucide-react';
import { inventoryService } from '../../services/inventory.service';
import clsx from 'clsx';

export const Inventory = () => {
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [importing, setImporting] = useState(false);
    const fileInputRef = useRef(null);

    // Form State
    const [formData, setFormData] = useState({
        name: '',
        sku: '',
        category: '',
        quantity: 0,
        unitPrice: 0,
        reorderPoint: 10
    });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        loadInventory();
    }, []);

    const loadInventory = async () => {
        try {
            setLoading(true);
            const data = await inventoryService.getAll();
            setItems(data);
        } catch (error) {
            console.error('Failed to load inventory', error);
        } finally {
            setLoading(false);
        }
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            setImporting(true);
            const result = await inventoryService.importInventory(file);
            alert(`Import Complete: ${result.results.success} added/updated, ${result.results.failed} failed.`);
            loadInventory();
        } catch (error) {
            console.error('Import failed', error);
            const msg = error.response?.data?.message || 'Failed to import file. Please check if you are logged in.';
            alert(msg);
        } finally {
            setImporting(false);
            e.target.value = null; // Reset input
        }
    };

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await inventoryService.addItem(formData);
            setIsAddModalOpen(false);
            setFormData({ name: '', sku: '', category: '', quantity: 0, unitPrice: 0, reorderPoint: 10 });
            loadInventory();
        } catch (error) {
            console.error('Failed to add item', error);
            alert('Failed to add item. SKU might be duplicate.');
        } finally {
            setSubmitting(false);
        }
    };

    const getStatus = (quantity, reorderPoint) => {
        if (quantity === 0) return 'Critical';
        if (quantity <= reorderPoint) return 'Low Stock';
        return 'Normal';
    };

    const columns = [
        { key: 'name', header: 'Product Name', render: (row) => <span className="font-medium text-gray-900">{row.name}</span> },
        { key: 'sku', header: 'SKU' },
        { key: 'category', header: 'Category' },
        {
            key: 'quantity', header: 'Current Stock', render: (row) => (
                <span className={clsx(
                    "font-semibold",
                    row.quantity <= row.reorderPoint ? "text-red-600" : "text-gray-900"
                )}>
                    {row.quantity}
                </span>
            )
        },
        { key: 'unitPrice', header: 'Unit Price', render: (row) => <span>${row.unitPrice}</span> },
        { key: 'reorderPoint', header: 'Reorder Level' },
        {
            key: 'status', header: 'Status', render: (row) => {
                const status = getStatus(row.quantity, row.reorderPoint);
                const statusStyles = {
                    'Normal': 'bg-green-100 text-green-800',
                    'Low Stock': 'bg-yellow-100 text-yellow-800',
                    'Critical': 'bg-red-100 text-red-800',
                };
                return (
                    <span className={clsx("px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full", statusStyles[status])}>
                        {status}
                    </span>
                );
            }
        }
    ];

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Inventory Management</h1>
                    <p className="mt-1 text-sm text-gray-500">Manage your products and monitor stock levels.</p>
                </div>
                <div className="flex space-x-3">
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        className="hidden"
                        accept=".xlsx, .xls, .csv"
                    />
                    <Button variant="secondary" size="sm" onClick={handleImportClick} isLoading={importing}>
                        <Upload className="h-4 w-4 mr-2" />
                        Import XLSX
                    </Button>
                    <Button size="sm" onClick={() => setIsAddModalOpen(true)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Product
                    </Button>
                </div>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent"></div>
                </div>
            ) : (
                <DataTable
                    title="All Products"
                    columns={columns}
                    data={items}
                />
            )}

            <Modal
                isOpen={isAddModalOpen}
                onClose={() => setIsAddModalOpen(false)}
                title="Add New Product"
                footer={
                    <>
                        <Button type="submit" form="add-product-form" className="ml-3" isLoading={submitting}>
                            Save Product
                        </Button>
                        <Button variant="secondary" onClick={() => setIsAddModalOpen(false)}>
                            Cancel
                        </Button>
                    </>
                }
            >
                <form id="add-product-form" onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <Input id="name" label="Product Name" value={formData.name} onChange={handleInputChange} required />
                        <Input id="sku" label="SKU" value={formData.sku} onChange={handleInputChange} required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <Input id="category" label="Category" value={formData.category} onChange={handleInputChange} />
                        <Input id="unitPrice" label="Unit Price ($)" type="number" value={formData.unitPrice} onChange={handleInputChange} required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <Input id="quantity" label="Initial Quantity" type="number" value={formData.quantity} onChange={handleInputChange} required />
                        <Input id="reorderPoint" label="Reorder Point" type="number" value={formData.reorderPoint} onChange={handleInputChange} required />
                    </div>
                </form>
            </Modal>
        </div>
    );
};

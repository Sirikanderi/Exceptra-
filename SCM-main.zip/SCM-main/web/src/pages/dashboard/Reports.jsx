import { FileText, Download, Share2, Sparkles, Upload } from 'lucide-react';
import { Button } from '../../components/common/Button';
import { FileUpload } from '../../components/common/FileUpload';
import { forecastingService } from '../../services/forecasting.service';
import { useState } from 'react';

export const Reports = () => {
    const [uploading, setUploading] = useState(false);
    const [uploadMessage, setUploadMessage] = useState('');

    const handleHistoryUpload = async (file) => {
        setUploading(true);
        setUploadMessage('');
        try {
            const res = await forecastingService.uploadHistory(file);
            setUploadMessage(`Success: ${res.message}`);
        } catch (error) {
            setUploadMessage('Failed to upload sales history.');
            console.error(error);
        } finally {
            setUploading(false);
        }
    };

    const reports = [
        { id: 1, title: 'Monthly Inventory Valuation', date: 'Oct 31, 2023', type: 'Financial', size: '2.4 MB' },
        { id: 2, title: 'Supplier Performance Review', date: 'Oct 15, 2023', type: 'Performance', size: '1.1 MB' },
        { id: 3, title: 'Quarterly Demand Forecast', date: 'Sep 30, 2023', type: 'Planning', size: '4.5 MB' },
        { id: 4, title: 'Logistics Efficiency Report', date: 'Sep 30, 2023', type: 'Operations', size: '1.8 MB' },
    ];

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics Center</h1>
                <Button>
                    Generate New Report
                </Button>
            </div>

            {/* AI Summary Section */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl p-6 text-white shadow-lg">
                <div className="flex items-start space-x-4">
                    <div className="p-2 bg-white/20 rounded-lg">
                        <Sparkles className="h-6 w-6 text-yellow-300" />
                    </div>
                    <div>
                        <h3 className="text-lg font-bold mb-1">AI Executive Summary</h3>
                        <p className="text-blue-100 leading-relaxed mb-4">
                            Overall supply chain efficiency has improved by <strong>12%</strong> this month.
                            Stockout risks are down, but logistics costs have risen slightly due to increased expedite shipments on the Mumbai-Delhi route.
                        </p>
                        <button className="text-sm font-medium bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition-colors">
                            View Detailed Insights
                        </button>
                    </div>
                </div>
            </div>

            {/* Quick Stats or Other Tools could go here */}

            {/* Recent Reports List */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-semibold text-gray-900">Recent Generated Reports</h3>
                    <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">View All</button>
                </div>
                <div className="divide-y divide-gray-100">
                    {reports.map((report) => (
                        <div key={report.id} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <div className="flex items-center space-x-4">
                                <div className="p-3 bg-red-50 rounded-lg">
                                    <FileText className="h-6 w-6 text-red-500" />
                                </div>
                                <div>
                                    <h4 className="text-sm font-medium text-gray-900">{report.title}</h4>
                                    <div className="flex items-center space-x-3 mt-1 text-xs text-gray-500">
                                        <span>{report.date}</span>
                                        <span>•</span>
                                        <span>{report.type}</span>
                                        <span>•</span>
                                        <span>{report.size}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center space-x-2">
                                <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                                    <Share2 className="h-4 w-4" />
                                </button>
                                <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg">
                                    <Download className="h-4 w-4" />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div >
    );
};

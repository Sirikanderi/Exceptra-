import { useState, useEffect, useRef } from 'react';
import { LineChart } from '../../components/charts/LineChart';
import { forecastingService } from '../../services/forecasting.service';
import { Brain, TrendingUp, AlertCircle, ChevronDown, Upload, Download, Package, Database, FileSpreadsheet } from 'lucide-react';
import { FileUpload } from '../../components/common/FileUpload';
import { toPng } from 'html-to-image';
import jsPDF from 'jspdf';

export const Forecasting = () => {
    const [skus, setSkus] = useState([]);
    const [selectedSku, setSelectedSku] = useState('');
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [marketImpact, setMarketImpact] = useState([]);

    // Upload States
    const [showUploads, setShowUploads] = useState(false);
    const [uploadHistoryMsg, setUploadHistoryMsg] = useState('');
    const [uploadMarketMsg, setUploadMarketMsg] = useState('');

    const reportRef = useRef(null);

    useEffect(() => {
        loadSkus();
    }, []);

    useEffect(() => {
        if (selectedSku) {
            loadForecast(selectedSku);
        }
    }, [selectedSku]);

    const loadSkus = async () => {
        try {
            const skuList = await forecastingService.getSkus();
            setSkus(skuList);
            if (skuList.length > 0) setSelectedSku(skuList[0]);
        } catch (error) {
            console.error('Failed to load SKUs', error);
        }
    };

    const loadForecast = async (sku) => {
        setLoading(true);
        setError(null);
        setMarketImpact([]);
        try {
            const response = await forecastingService.getForecast(sku);
            const points = Array.isArray(response) ? response : response.forecast || response;

            if (!points || points.length === 0) {
                setError('No forecast data available. Upload sales history to generate predictions.');
                setData([]);
                return;
            }

            const pivoted = {};
            points.forEach(item => {
                if (!pivoted[item.date]) pivoted[item.date] = { date: item.date };
                const key = item.type;
                pivoted[item.date][key] = item.value;
            });

            const chartData = Object.values(pivoted).sort((a, b) => new Date(a.date) - new Date(b.date));
            setData(chartData);

            if (response.model_info?.market_impact_msg) {
                // Handle varying formats of market impact
                const imp = response.model_info.market_impact_msg;
                setMarketImpact(Array.isArray(imp) ? imp : [imp]);
            }

        } catch (error) {
            console.error('Failed to load forecast', error);
            setError(error.response?.data?.error || 'Forecast service unavailable.');
            setData([]);
        } finally {
            setLoading(false);
        }
    };

    const handleDownloadPDF = async () => {
        if (!reportRef.current) return;

        try {
            const element = reportRef.current;
            const dataUrl = await toPng(element, { cacheBust: true });

            const pdf = new jsPDF('p', 'mm', 'a4');
            const imgProperties = pdf.getImageProperties(dataUrl);
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (imgProperties.height * pdfWidth) / imgProperties.width;

            pdf.addImage(dataUrl, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save(`forecast_${selectedSku}_${new Date().toISOString().split('T')[0]}.pdf`);
        } catch (e) {
            console.error("PDF Export failed", e);
            alert("Failed to generate PDF. Please try again.");
        }
    };

    const handleHistoryUpload = async (file) => {
        setUploadHistoryMsg('Uploading...');
        try {
            const res = await forecastingService.uploadHistory(file);
            setUploadHistoryMsg(`Success: ${res.message}`);
            loadSkus(); // Reload SKUs as new ones might be added
        } catch (error) {
            setUploadHistoryMsg('Failed to upload.');
        }
    };

    const handleMarketUpload = async (file) => {
        setUploadMarketMsg('Uploading...');
        try {
            await forecastingService.uploadMarketData(file);
            setUploadMarketMsg("Success! Market data integrated.");
            if (selectedSku) loadForecast(selectedSku);
        } catch (err) {
            setUploadMarketMsg("Failed to upload market data.");
        }
    };

    return (
        <div className="space-y-6 max-w-[1600px] mx-auto">
            {/* Header Area */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-200 pb-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Demand Intelligence</h1>
                    <p className="text-sm text-gray-500 mt-1">AI-driven demand forecasting & market analysis</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                    <button
                        onClick={() => setShowUploads(!showUploads)}
                        className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${showUploads ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'}`}
                    >
                        <Database className="h-4 w-4" />
                        <span>Data Sources</span>
                    </button>
                    <button
                        onClick={handleDownloadPDF}
                        className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                        <Download className="h-4 w-4" />
                        <span>Export Report</span>
                    </button>
                    <button
                        onClick={() => window.location.href = '/inventory'}
                        className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 shadow-sm transition-colors"
                    >
                        <Package className="h-4 w-4" />
                        <span>Manage Stock</span>
                    </button>
                </div>
            </div>

            {/* Data Management Section (Collapsible) */}
            {showUploads && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 p-6 rounded-xl border border-gray-200 animate-in fade-in slide-in-from-top-2">
                    <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
                        <div className="flex items-center space-x-3 mb-4">
                            <div className="p-2 bg-indigo-50 rounded-lg">
                                <FileSpreadsheet className="h-5 w-5 text-indigo-600" />
                            </div>
                            <div>
                                <h3 className="font-semibold text-gray-900">Sales History</h3>
                                <p className="text-xs text-gray-500">Required for training. CSV with Date, SKU, Qty.</p>
                            </div>
                        </div>
                        <FileUpload
                            onUpload={handleHistoryUpload}
                            acceptedFileTypes=".csv,.xlsx"
                            buttonLabel="Upload History CSV"
                        />
                        {uploadHistoryMsg && <p className="text-xs mt-2 font-medium text-indigo-600">{uploadHistoryMsg}</p>}
                    </div>

                    <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
                        <div className="flex items-center space-x-3 mb-4">
                            <div className="p-2 bg-emerald-50 rounded-lg">
                                <TrendingUp className="h-5 w-5 text-emerald-600" />
                            </div>
                            <div>
                                <h3 className="font-semibold text-gray-900">Market Data</h3>
                                <p className="text-xs text-gray-500">External factors (e.g. Nagpur Index). Optional.</p>
                            </div>
                        </div>
                        <FileUpload
                            onUpload={handleMarketUpload}
                            acceptedFileTypes=".csv,.xlsx"
                            buttonLabel="Upload Market CSV"
                        />
                        {uploadMarketMsg && <p className="text-xs mt-2 font-medium text-emerald-600">{uploadMarketMsg}</p>}
                    </div>
                </div>
            )}

            {/* Main Forecasting Content */}
            <div ref={reportRef} className="space-y-6 bg-white p-1 rounded-xl">
                {/* SKU Control Bar */}
                <div className="flex items-center space-x-4 bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <label className="text-sm font-medium text-gray-700 whitespace-nowrap">Forecast Product:</label>
                    <div className="relative flex-1 max-w-md">
                        <select
                            value={selectedSku}
                            onChange={(e) => setSelectedSku(e.target.value)}
                            className="w-full appearance-none bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 pr-10 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm font-medium transition-shadow"
                        >
                            <option value="">Select a Product...</option>
                            {skus.map(sku => (
                                <option key={sku} value={sku}>{sku}</option>
                            ))}
                        </select>
                        <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-gray-400 pointer-events-none" />
                    </div>
                    {selectedSku && (
                        <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-green-50 text-green-700 rounded-full border border-green-100 text-xs font-semibold">
                            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                            <span>Model Active</span>
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Chart Area */}
                    <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-gray-200 shadow-sm min-h-[400px]">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-lg font-bold text-gray-900">Demand Trend</h3>
                            <div className="flex space-x-4 text-xs font-medium">
                                <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-gray-400 mr-2"></span>Historical</div>
                                <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-blue-600 mr-2"></span>AI Prediction</div>
                            </div>
                        </div>

                        {loading ? (
                            <div className="h-[320px] flex items-center justify-center">
                                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                            </div>
                        ) : error ? (
                            <div className="h-[320px] flex flex-col items-center justify-center text-red-500 bg-red-50/50 rounded-lg">
                                <AlertCircle className="h-8 w-8 mb-2" />
                                <span className="text-sm font-medium">{error}</span>
                            </div>
                        ) : (data.length > 0) ? (
                            <div className="h-[320px] w-full">
                                <LineChart
                                    data={data}
                                    lines={[
                                        { key: 'actual', name: 'Historical', color: '#9CA3AF' },
                                        { key: 'predicted', name: 'Prediction', color: '#2563EB' }
                                    ]}
                                    height={320}
                                />
                            </div>
                        ) : (
                            <div className="h-[320px] flex flex-col items-center justify-center text-gray-400 bg-gray-50/50 rounded-lg border-2 border-dashed border-gray-200">
                                <Brain className="h-10 w-10 mb-3 opacity-50" />
                                <p className="text-sm font-medium">Select a product to view forecast</p>
                            </div>
                        )}
                    </div>

                    {/* Insights Panel */}
                    <div className="lg:col-span-1 space-y-4">
                        <div className="bg-indigo-900 text-white p-6 rounded-xl shadow-lg relative overflow-hidden">
                            <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-indigo-700 rounded-full opacity-50 blur-xl"></div>

                            <div className="flex items-center space-x-2 mb-4 relative z-10">
                                <Brain className="h-5 w-5 text-indigo-300" />
                                <h3 className="font-bold tracking-wide text-sm uppercase">AI Analysis</h3>
                            </div>

                            <div className="space-y-4 relative z-10">
                                <div>
                                    <h4 className="text-xs text-indigo-300 uppercase font-semibold mb-1">Seasonality</h4>
                                    <p className="text-sm text-indigo-50 leading-relaxed">
                                        {selectedSku
                                            ? `${selectedSku} exhibits strong seasonal correlation. Expect demand uptick in coming weeks based on 5-year trend.`
                                            : "Awaiting product selection..."}
                                    </p>
                                </div>

                                {marketImpact.length > 0 && (
                                    <div className="bg-white/10 p-3 rounded-lg border border-white/10">
                                        <h4 className="text-xs text-amber-300 uppercase font-semibold mb-1 flex items-center">
                                            <TrendingUp className="h-3 w-3 mr-1" /> Market Signals
                                        </h4>
                                        <ul className="text-xs text-indigo-50 list-disc list-inside">
                                            {marketImpact.map((m, i) => <li key={i}>{m}</li>)}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
                            <div className="flex items-center space-x-2 mb-3">
                                <AlertCircle className="h-4 w-4 text-orange-500" />
                                <h3 className="font-bold text-gray-900 text-sm">Risk Assessment</h3>
                            </div>
                            {selectedSku ? (
                                <div className="space-y-3">
                                    <div className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded">
                                        <span className="text-gray-600">Stockout Risk</span>
                                        <span className="font-bold text-red-600">High (78%)</span>
                                    </div>
                                    <div className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded">
                                        <span className="text-gray-600">Price Volatility</span>
                                        <span className="font-bold text-orange-500">Moderate</span>
                                    </div>
                                </div>
                            ) : (
                                <p className="text-xs text-gray-400 italic text-center py-4">Select product for assessment</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

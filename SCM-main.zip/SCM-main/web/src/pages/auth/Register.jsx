import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../auth/useAuth';
import { Input } from '../../components/common/Input';
import { Button } from '../../components/common/Button';

export const Register = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        role: 'shopkeeper', // Default role
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { register } = useAuth();
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log("Register form submitted", formData);
        setError('');
        setLoading(true);

        try {
            const response = await register(formData);
            console.log("Register response:", response);

            if (response?.data?.user?.role === 'driver') {
                navigate('/driver');
            } else {
                navigate('/dashboard');
            }
        } catch (err) {
            console.error("Register error:", err);
            const serverError = err.response?.data?.error || err.response?.data?.message;
            setError(serverError || 'Failed to create account.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <h2 className="mt-6 text-2xl font-bold text-gray-900">Create a new account</h2>
            <p className="mt-2 text-sm text-gray-600 mb-8">
                Already have an account?{' '}
                <Link to="/auth/login" className="font-medium text-blue-600 hover:text-blue-500">
                    Sign in
                </Link>
            </p>

            <form className="space-y-6" onSubmit={handleSubmit}>
                {error && (
                    <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">
                        {error}
                    </div>
                )}

                <Input
                    id="name"
                    type="text"
                    label="Full Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="John Doe"
                />

                <Input
                    id="email"
                    type="email"
                    label="Email address"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    autoComplete="email"
                    placeholder="name@company.com"
                />

                <Input
                    id="password"
                    type="password"
                    label="Password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                    autoComplete="new-password"
                    placeholder="••••••••"
                />

                <div>
                    <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">
                        Role
                    </label>
                    <select
                        id="role"
                        value={formData.role}
                        onChange={handleChange}
                        className="block w-full rounded-lg border-gray-300 border shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2.5"
                    >
                        <option value="shopkeeper">Shopkeeper</option>
                        <option value="supplier">Supplier</option>
                        <option value="driver">Driver</option>
                    </select>
                </div>

                <div className="pt-2">
                    <Button
                        type="submit"
                        className="w-full flex justify-center py-2.5"
                        isLoading={loading}
                        onClick={() => console.log("Register button clicked")}
                    >
                        Create Account
                    </Button>
                </div>
            </form>
        </div>
    );
};

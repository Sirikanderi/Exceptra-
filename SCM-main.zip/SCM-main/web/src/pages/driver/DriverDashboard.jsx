import { useState } from 'react';
import { DriverRouteMap } from '../../components/maps/DriverRouteMap';
import { RouteUpdateModal } from '../../components/driver/RouteUpdateModal';
import { AlertCircle, Clock, Navigation, CheckCircle2, ChevronRight, Truck, MapPin } from 'lucide-react';
import axios from 'axios';
import { env } from '../../config/env.config';
import { useNavigate } from 'react-router-dom';

export const DriverDashboard = () => {
    const navigate = useNavigate();
    // Initial Delivery State
    const [route, setRoute] = useState({
        deliveryId: 'DEL-88592',
        origin: 'Nagpur, Maharashtra',
        originCoords: [79.0882, 21.1458], // [lng, lat]
        destination: 'Mumbai, Maharashtra',
        destinationCoords: [72.8777, 19.0760], // [lng, lat]
        startTime: '8:10 PM',
        distance: '780 km',
        currentLocation: 'Wardha',
        status: 'IN_TRANSIT'
    });

    const [status, setStatus] = useState({
        routeStatus: 'On Time',
        eta: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(),
        delayMinutes: 0
    });

    return (
        <div className="flex flex-col gap-6 h-full">
            {/* Top Stat Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-2xl p-6 shadow-lg shadow-blue-900/20">
                    <p className="text-blue-100 text-xs font-semibold uppercase tracking-wider mb-2">Active Task</p>
                    <div className="flex justify-between items-end">
                        <div>
                            <h3 className="text-2xl font-bold">{route.deliveryId}</h3>
                            <p className="text-blue-100 text-sm mt-1 flex items-center gap-1">
                                <Truck className="w-4 h-4" />
                                In Transit
                            </p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                    <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">ETA</p>
                    <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-blue-500" />
                        <span className="text-2xl font-bold text-gray-900">
                            {new Date(status.eta).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                    </div>
                    <p className={`text-xs mt-2 font-medium ${status.delayMinutes > 0 ? 'text-amber-600' : 'text-green-600'}`}>
                        {status.delayMinutes > 0 ? `+${status.delayMinutes} min delay` : 'On Time'}
                    </p>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                    <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Distance Remaining</p>
                    <div className="flex items-center gap-2">
                        <Navigation className="w-5 h-5 text-purple-500" />
                        <span className="text-2xl font-bold text-gray-900">342 km</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-2">Total: {route.distance}</p>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 cursor-pointer hover:border-blue-200 transition-colors group" onClick={() => navigate('/driver/map')}>
                    <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Next Stop</p>
                    <h3 className="text-xl font-bold text-gray-900 truncate">{route.destination.split(',')[0]}</h3>
                    <div className="flex items-center gap-2 mt-2 text-blue-600 font-medium text-sm group-hover:underline">
                        View Map <ChevronRight className="w-4 h-4" />
                    </div>
                </div>
            </div>

            {/* Quick Actions & Recent Activity */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
                {/* Main Card: Route Overview */}
                <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col">
                    <h3 className="text-lg font-bold text-gray-900 mb-6">Route Overview</h3>
                    <div className="flex-1 rounded-xl overflow-hidden relative border border-gray-200 mb-6 bg-gray-50 flex items-center justify-center group" onClick={() => navigate('/driver/map')}>
                        {/* Mini Map Visual (Could be an image or simplified map) */}
                        <div className="text-center">
                            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mx-auto mb-3 group-hover:scale-110 transition-transform">
                                <Navigation className="w-8 h-8" />
                            </div>
                            <p className="text-gray-900 font-medium">View Detailed Map</p>
                            <p className="text-gray-500 text-sm">Click to see live traffic and updates</p>
                        </div>
                    </div>
                </div>

                {/* Right Panel: Actions */}
                <div className="flex flex-col gap-4">
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                        <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
                        <div className="space-y-3">
                            <button
                                onClick={() => navigate('/driver/route-update')}
                                className="w-full flex items-center gap-3 p-4 rounded-xl border border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-all text-left group"
                            >
                                <div className="bg-blue-100 p-2 rounded-lg text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                    <AlertCircle className="w-5 h-5" />
                                </div>
                                <div>
                                    <p className="font-semibold text-gray-900">Report Issue</p>
                                    <p className="text-xs text-gray-500">Traffic, Accident, Breakdown</p>
                                </div>
                            </button>

                            <button
                                onClick={() => navigate('/driver/delivery')}
                                className="w-full flex items-center gap-3 p-4 rounded-xl border border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-all text-left group"
                            >
                                <div className="bg-purple-100 p-2 rounded-lg text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                                    <Clock className="w-5 h-5" />
                                </div>
                                <div>
                                    <p className="font-semibold text-gray-900">Log Break</p>
                                    <p className="text-xs text-gray-500">Rest Stop, Fuel</p>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

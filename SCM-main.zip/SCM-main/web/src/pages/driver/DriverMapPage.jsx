import { useState } from 'react';
import { DriverRouteMap } from '../../components/maps/DriverRouteMap';
import { RouteUpdateModal } from '../../components/driver/RouteUpdateModal';
import { AlertCircle, CheckCircle2, Navigation } from 'lucide-react';
import axios from 'axios';
import { env } from '../../config/env.config';

export const DriverMapPage = () => {
    // Shared state logic (similar to previous dashboard)
    const [route, setRoute] = useState({
        deliveryId: 'DEL-88592',
        origin: 'Nagpur, Maharashtra',
        originCoords: [79.0882, 21.1458],
        destination: 'Mumbai, Maharashtra',
        destinationCoords: [72.8777, 19.0760],
        status: 'IN_TRANSIT'
    });

    const [isFormOpen, setIsFormOpen] = useState(false);
    const [oldRouteActive, setOldRouteActive] = useState(false);
    const [toast, setToast] = useState(null);
    const [diversionPoint, setDiversionPoint] = useState(null);

    const handleMapClick = (e) => {
        if (oldRouteActive) {
            showToast('info', 'Route already updated.');
            return;
        }
        const lat = e.latLng.lat();
        const lng = e.latLng.lng();
        setDiversionPoint({ lat, lng });
        showToast('info', 'Point selected. Click "Report Route Change" to update.');
    };

    const handleRouteChangeSubmit = async (data) => {
        try {
            setOldRouteActive(true);
            // API Call Simulation
            await axios.post(`${env.API_URL}/logistics/route-change`, {
                deliveryId: data.deliveryId,
                reason: data.reason,
                driverNotes: data.notes,
                oldRoute: {},
                newRoute: {},
                timestamp: new Date().toISOString()
            }, {
                headers: { 'Authorization': `Bearer ${localStorage.getItem('scm_token')}` }
            });

            setDiversionPoint(null);
            showToast('success', 'Route updated successfully.');

        } catch (error) {
            console.error(error);
            showToast('error', 'Failed to update route');
            setOldRouteActive(false);
        }
    };

    const showToast = (type, message) => {
        setToast({ type, message });
        setTimeout(() => setToast(null), 4000);
    };

    return (
        <div className="h-full relative rounded-2xl overflow-hidden shadow-sm border border-gray-200 bg-white">
            <DriverRouteMap
                originCoords={route.originCoords}
                destinationCoords={route.destinationCoords}
                oldRouteActive={oldRouteActive}
                onMapClick={handleMapClick}
                diversionPoint={diversionPoint}
            />

            {/* Floating Updates Panel */}
            <div className="absolute bottom-6 left-6 right-6 md:left-auto md:w-96 flex flex-col gap-4">
                {/* Instructions */}
                {!oldRouteActive && !diversionPoint && (
                    <div className="bg-white/90 backdrop-blur px-4 py-3 rounded-xl shadow-lg border border-gray-200 animate-in fade-in slide-in-from-bottom-4">
                        <p className="text-sm text-gray-600">
                            <span className="font-bold text-gray-900">Instruction:</span> Click on the map to set a diversion point.
                        </p>
                    </div>
                )}

                {/* Update Button */}
                {(diversionPoint || oldRouteActive) && (
                    <div className="bg-white p-4 rounded-xl shadow-2xl border border-gray-200 animate-in slide-in-from-bottom-4">
                        {oldRouteActive ? (
                            <div className="flex items-center gap-3 text-green-600 bg-green-50 p-3 rounded-lg border border-green-100">
                                <CheckCircle2 className="w-5 h-5" />
                                <div>
                                    <p className="font-bold text-sm">Route Updated</p>
                                    <p className="text-xs">Follow the new solid blue path.</p>
                                </div>
                            </div>
                        ) : (
                            <div>
                                <h3 className="font-bold text-gray-900 mb-1">Diversion Selected</h3>
                                <p className="text-xs text-gray-500 mb-3">Coordinates: {diversionPoint.lat.toFixed(4)}, {diversionPoint.lng.toFixed(4)}</p>
                                <button
                                    onClick={() => setIsFormOpen(true)}
                                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-lg shadow-lg shadow-blue-500/20 transition-all flex justify-center items-center gap-2"
                                >
                                    <Navigation className="w-4 h-4" />
                                    Report Route Change
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <RouteUpdateModal
                isOpen={isFormOpen}
                onClose={() => setIsFormOpen(false)}
                onSubmit={handleRouteChangeSubmit}
                deliveryId={route.deliveryId}
                initialCoordinates={diversionPoint}
            />

            {toast && (
                <div className={`fixed top-24 right-8 z-50 px-5 py-3 rounded-lg shadow-xl text-white font-medium text-sm flex items-center gap-2 animate-in slide-in-from-top-2 ${toast.type === 'success' ? 'bg-green-600' : 'bg-slate-800'
                    }`}>
                    {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                    {toast.message}
                </div>
            )}
        </div>
    );
};

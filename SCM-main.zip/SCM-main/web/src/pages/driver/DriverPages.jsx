import { Truck, MapPin, Clock, Calendar, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

export const DriverDelivery = () => {
    return (
        <div className="flex flex-col gap-6">
            <h1 className="text-2xl font-bold text-gray-900">Active Delivery Details</h1>
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-6 mb-8 border-b border-gray-100 pb-8">
                    <div>
                        <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold uppercase tracking-wide">In Transit</span>
                        <h2 className="text-3xl font-bold text-gray-900 mt-2">DEL-88592</h2>
                        <p className="text-gray-500 mt-1">Assigned on Jan 19, 2026</p>
                    </div>
                    <div className="text-right">
                        <p className="text-sm text-gray-500">Estimated Arrival</p>
                        <p className="text-2xl font-bold text-gray-900">8:45 PM</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="relative pl-8 border-l-2 border-dashed border-gray-200 space-y-10">
                        <div className="relative">
                            <div className="absolute -left-[37px] top-1 w-4 h-4 rounded-full bg-green-500 border-4 border-white shadow-sm"></div>
                            <h3 className="font-bold text-gray-900 text-lg">Nagpur, Maharashtra</h3>
                            <p className="text-gray-500 text-sm">Picked up at 8:10 PM</p>
                            <p className="text-xs text-gray-400 mt-1">Warehouse A-4</p>
                        </div>
                        <div className="relative">
                            <div className="absolute -left-[37px] top-1 w-4 h-4 rounded-full bg-blue-500 border-4 border-white shadow-sm ring-4 ring-blue-50"></div>
                            <h3 className="font-bold text-gray-900 text-lg">Mumbai, Maharashtra</h3>
                            <p className="text-gray-500 text-sm">Expected 8:45 PM</p>
                            <p className="text-xs text-gray-400 mt-1">Distribution Center West</p>
                        </div>
                    </div>

                    <div className="bg-gray-50 rounded-xl p-6">
                        <h4 className="font-bold text-gray-900 mb-4">Cargo Manifest</h4>
                        <ul className="space-y-3">
                            <li className="flex justify-between text-sm">
                                <span className="text-gray-600">Steel Rods (Type A)</span>
                                <span className="font-medium text-gray-900">2.5 Tons</span>
                            </li>
                            <li className="flex justify-between text-sm">
                                <span className="text-gray-600">Industrial Bearings</span>
                                <span className="font-medium text-gray-900">500 Units</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const DriverHistory = () => {
    return (
        <div className="flex flex-col gap-6">
            <h1 className="text-2xl font-bold text-gray-900">Delivery History</h1>
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="px-6 py-4 font-semibold text-gray-600 hover:text-gray-900">ID</th>
                            <th className="px-6 py-4 font-semibold text-gray-600">Date</th>
                            <th className="px-6 py-4 font-semibold text-gray-600">Route</th>
                            <th className="px-6 py-4 font-semibold text-gray-600">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {[1, 2, 3].map((i) => (
                            <tr key={i} className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-4 font-medium text-gray-900">DEL-880${i}</td>
                                <td className="px-6 py-4 text-gray-500">Jan {10 + i}, 2026</td>
                                <td className="px-6 py-4 text-gray-500">Pune → Nashik</td>
                                <td className="px-6 py-4">
                                    <span className="px-2 py-1 rounded text-xs font-bold bg-green-100 text-green-700">COMPLETED</span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

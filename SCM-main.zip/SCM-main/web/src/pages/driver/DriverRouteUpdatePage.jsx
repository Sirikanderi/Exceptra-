import { useState } from 'react';
import { Navigation, AlertTriangle, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const DriverRouteUpdatePage = () => {
    const navigate = useNavigate();
    const [reason, setReason] = useState('Traffic');
    const [notes, setNotes] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // In a real app this would post data and then redirect
        navigate('/driver/map');
    };

    return (
        <div className="max-w-2xl mx-auto">
            <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 hover:text-gray-900 mb-6 font-medium">
                <ArrowLeft className="w-4 h-4" />
                Back
            </button>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
                <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 bg-amber-50 rounded-full flex items-center justify-center text-amber-600">
                        <AlertTriangle className="w-6 h-6" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Report Route Change</h1>
                        <p className="text-gray-500">Submit details about the diversion or delay.</p>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Primary Reason</label>
                        <select
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 bg-gray-50 text-gray-900 font-medium"
                        >
                            <option value="Traffic">Heavy Traffic / Congestion</option>
                            <option value="Accident">Accident on Route</option>
                            <option value="RoadClosed">Road Closure / Construction</option>
                            <option value="Weather">Weather Conditions</option>
                            <option value="Breakdown">Vehicle Breakdown</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Additional Notes</label>
                        <textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            rows={4}
                            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 bg-gray-50 text-gray-900 placeholder-gray-400"
                            placeholder="Describe the situation..."
                        />
                    </div>

                    <div className="pt-4">
                        <button
                            type="submit"
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/20 transition-all flex justify-center items-center gap-2"
                        >
                            <Navigation className="w-5 h-5" />
                            Submit Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from pymongo import MongoClient
import os
from datetime import datetime, timedelta

app = Flask(__name__)

from dotenv import load_dotenv
import os

# Load env from backend directory
backend_env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'backend', '.env')
load_dotenv(backend_env_path)

# URI from env (Atlas), fallback to localhost
MONGO_URI = os.getenv('MONGO_URI')
if not MONGO_URI:
    MONGO_URI = 'mongodb://localhost:27017/scm_db'

client = MongoClient(MONGO_URI)
# Mongoose on Atlas often defaults to 'test' database if not specified in URI
# Check if URI determines DB, otherwise 'test'
db = client.get_database('test') 
sales_collection = db['saleshistories'] 

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "UP", "service": "ARIMA Forecasting Engine"})

@app.route('/train-predict', methods=['POST'])
def train_and_predict():
    try:
        print("Received request", flush=True) # Debug log
        data = request.json
        print(f"Data: {data}", flush=True)
        sku = data.get('sku')
        periods = int(data.get('periods', 30)) # Forecast next 30 days/months

        if not sku:
            return jsonify({"error": "SKU is required"}), 400

        # 1. Fetch Historical Data from MongoDB
        # We can either fetch via Mongoose and pass here, or let Python fetch directly.
        # Direct fetch is faster for analytics.
        # 1. Fetch Historical Data
        cursor = sales_collection.find({"sku": sku}).sort("date", 1)
        df = pd.DataFrame(list(cursor))
        print(f"Found {len(df)} records for SKU {sku}", flush=True)

        if df.empty:
            print("DataFrame is empty", flush=True)
            return jsonify({"error": "No historical data found for this SKU"}), 404

        # 2. Preprocess
        df['date'] = pd.to_datetime(df['date'])
        df.set_index('date', inplace=True)
        ts_data = df['quantitySold'].resample('D').sum().fillna(0)

        # 3. Train ARIMA
        # In a real SARIMAX, we would pass 'exog' (market data) here.
        # For simplicity/robustness in this Hackathon, we will:
        # A. Train simple ARIMA on history.
        # B. Fetch Market Data for the FUTURE periods.
        # C. Apply a post-processing multiplier if Market Index is high.
        
        model = ARIMA(ts_data, order=(5,1,0)) 
        model_fit = model.fit()
        forecast_result = model_fit.forecast(steps=periods)
        
        # 4. Fetch Market Data (Nagpur/General)
        market_collection = db['marketdatas'] # Mongoose pluralization check
        future_start = ts_data.index[-1] + timedelta(days=1)
        future_end = ts_data.index[-1] + timedelta(days=periods)
        
        market_cursor = market_collection.find({
            "date": {"$gte": future_start, "$lte": future_end}
        })
        market_df = pd.DataFrame(list(market_cursor))
        
        # 5. Apply "Crazy" Market Boost
        final_forecast = []
        forecast_dates = [future_start + timedelta(days=x) for x in range(periods)]
        
        market_impact_msg = []

        # Optimization: Create a lookup dictionary for O(1) access
        # Key: Date (date object), Value: Market Index Value
        market_lookup = {}
        if not market_df.empty:
            # Ensure we are working with date objects for keys
            market_df['date'] = pd.to_datetime(market_df['date'])
            market_df['date_only'] = market_df['date'].dt.date
            # Create dict: { datetime.date(2025,1,1): 85.0, ... }
            market_lookup = market_df.set_index('date_only')['value'].to_dict()

        for i, date in enumerate(forecast_dates):
            base_val = forecast_result.iloc[i]
            boost = 1.0
            
            # Fast Lookup
            lookup_date = date.date()
            if lookup_date in market_lookup:
                val = market_lookup[lookup_date]
                
                # Logic: Index > 80 (High), < 30 (Low)
                if val > 80:
                    boost = 1.5
                    if "High Demand Detected" not in market_impact_msg:
                        market_impact_msg.append("High Demand Detected")
                elif val < 30:
                    boost = 0.8
            
            final_forecast.append(base_val * boost)
        
        history_points = [{"date": str(d.date()), "value": float(v), "type": "actual"} for d, v in ts_data.tail(60).items()] 
        forecast_points = [{"date": str(d.date()), "value": float(v), "type": "predicted"} for d, v in zip(forecast_dates, final_forecast)]

        combined_data = history_points + forecast_points

        return jsonify({
            "sku": sku,
            "forecast": combined_data,
            "model_info": {
                "aic": model_fit.aic,
                "order": "(5,1,0)",
                "market_impact": market_impact_msg
            }
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Error: {e}", flush=True)
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=5001, debug=False)
